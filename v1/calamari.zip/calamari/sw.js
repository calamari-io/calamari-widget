// Service worker — jedyne miejsce, które zna stan.
// Warianty interfejsu (pigułka, side panel, okno) są tylko wyświetlaczami.

import { Api, elapsedSeconds, workingSeconds, dayTotals, fmtShort, pageTransportTest,
         probeStart, probeStop, probeRead, probeAppend, probeClear,
         localISODate, currentTransport, resolveTransport,
         sessionCookieInfo, tenantHost } from './lib/api.js';

/* Kalendarz nieobecności przychodzi z API jako jedna płaska lista zdarzeń całej
   firmy. Rozdzielenie na „moje" i „kto dziś poza biurem" wymaga wiedzy, kim jest
   zalogowany użytkownik — a tę ma dopiero ten moduł, po zebraniu main-frame.

   Nie pokazujemy siebie na liście nieobecnych: pracownik wie, że jest na urlopie.
   Własne wolne idzie do osobnej sekcji „zaplanowane nieobecności". */
function splitCalendar(events, meId) {
  const today = localISODate();
  const mine = [], out = [];
  for (const e of events) {
    const trwa = e.start <= today && e.end >= today;
    const swoje = meId != null && e.empId != null && String(e.empId) === String(meId);
    if (swoje) {
      // własne: i trwające, i nadchodzące — oba są „zaplanowane nieobecności"
      if (e.end >= today) mine.push(e);
    } else if (trwa) {
      out.push(e);
    }
  }
  mine.sort(byStart);
  out.sort((a, b) => a.name.localeCompare(b.name, 'pl'));
  const osoba = e => ({
    name: e.name,
    initials: initials(e.name),
    avatar: e.avatar || null,
    typeName: e.typeName,
    start: e.start,
    end: e.end,
    pending: e.pending
  });
  return {
    mine: mine.slice(0, 4).map(e => ({
      from: e.start, to: e.end, typeName: e.typeName, pending: e.pending
    })),
    // Dwie grupy, tak jak w kalendarzu Calamari: kategoria TIMEOFF to
    // nieobecność, WORK to praca poza biurem. Podziału dokonuje serwer
    // (filtr absenceCategories), my tylko rozdzielamy gotowy wynik.
    today: {
      timeoff: out.filter(e => e.category !== 'WORK').map(osoba),
      work:    out.filter(e => e.category === 'WORK').map(osoba)
    }
  };
}

function byStart(a, b) { return a.start < b.start ? -1 : a.start > b.start ? 1 : 0; }

function initials(name) {
  return String(name || '').trim().split(/\s+/).slice(0, 2)
    .map(w => w[0] ? w[0].toUpperCase() : '').join('');
}

const DEFAULTS = {
  variant: 'pill',          // pill | sidepanel | window
  modLeave: true,
  modTime: true,
  pillHidden: false,
  lang: '',          // puste = jak na koncie Calamari
  pillPos: { right: 28, bottom: 28 }
};

async function settings() {
  const r = await chrome.storage.sync.get(Object.keys(DEFAULTS));
  return { ...DEFAULTS, ...r };
}

/* ------------------------------------------------------------ stan + badge */

const epoch = Date.now();
let revision = 0, writePending = null;
let pendingSnapshot = null, cachedSnapshot = null, latestSnapshot = null, generation = 0;
function invalidate() { generation++; cachedSnapshot = null; pendingSnapshot = null; }
async function snapshot(force = false, confirmingWrite = false) {
  if (force) cachedSnapshot = null;
  if (cachedSnapshot && Date.now() - cachedSnapshot.fetchedAt < 5000) return cachedSnapshot;
  if (pendingSnapshot) return pendingSnapshot;
  const version = generation;
  const job = (async () => {
    const s = await settings();
    // Confirm the clock write without waiting for the unrelated absence
    // calendar. The next ordinary refresh fetches the other sections again.
    const previous = confirmingWrite ? latestSnapshot : null;
    const [screenResult, availResult, absenceResult, projectResult, me, mode] = await Promise.all([
      Api.clockScreen(), Api.availability(), s.modLeave ? (previous ? previous.absence : Api.absence()) : null,
      s.modTime ? Api.currentProject() : null,
      previous ? previous.me : Api.me(), chrome.storage.sync.get('dataMode')
    ]);
    if (version !== generation) return confirmingWrite ? snapshot(false, true) : readSnapshot();
    const screen = screenResult._error ? null : screenResult;
    const avail = availResult._error ? { available: false, reason: 'Brak połączenia' } : availResult;
    let absence = absenceResult?._error ? null : absenceResult;
    // Kalendarz firmowy dzielimy dopiero tutaj — Api.absence() nie wie, kim jesteśmy.
    if (absence && Array.isArray(absence.calendar)) {
      absence = { ...absence, ...splitCalendar(absence.calendar, me && me.id) };
    }
    const error = screenResult._error || availResult._error || absenceResult?._error;
    const mock = mode.dataMode === 'mock';
    // Transport rozstrzyga api.js przy pierwszym odczycie: „direct" znaczy,
    // że karta Calamari nie jest potrzebna, „page" że jednak tak.
    const diag = { live: !mock && !error, transport: mock ? null : (currentTransport() || 'page'),
      kind: mock ? 'TRYB_ATRAPY' : error?.kind || null, detail: error?.detail || null };
    const snap = {
      epoch, revision: ++revision, screen, avail, absence, me, settings: s, diag,
      absenceError: absenceResult?._error || null,
      project: projectResult?._error ? null : projectResult,
      sampledAt: screen?._receivedAt || Date.now(), fetchedAt: Date.now(),
      seconds: screen ? elapsedSeconds(screen) : null,
      workSeconds: screen ? workingSeconds(screen) : null,
      // sumy całego dnia — po zakończeniu pracy to one trafiają na duży licznik
      dayWorkSeconds: screen ? dayTotals(screen).work : null,
      dayBreakSeconds: screen ? dayTotals(screen).brk : null,
      state: !screen ? 'UNKNOWN' : screen.currentState === 'STOPPED' ? 'STOPPED'
           : screen.currentState === 'BREAK' ? 'BREAK' : 'WORKING'
    };
    cachedSnapshot = snap;
    latestSnapshot = snap;
    await chrome.storage.local.set({ diag });
    return snap;
  })();
  pendingSnapshot = job;
  try { return await job; }
  finally { if (pendingSnapshot === job) pendingSnapshot = null; }
}

/* „Czy widżet potrzebuje otwartej karty?" — pytanie, które prototyp ma
   rozstrzygnąć u konkretnego klienta, bo odpowiedź zależy od ustawień
   ciasteczek na jego koncie. Przycisk w opcjach wymusza ponowne sprawdzenie. */
async function transportTest() {
  const host = await tenantHost();
  if (!host) return { ok: false, detail: 'Najpierw wpisz subdomenę konta.' };
  const t0 = Date.now();
  const mode = await resolveTransport(true);
  return {
    ok: true, mode, ms: Date.now() - t0, host,
    ciasteczka: await sessionCookieInfo(host)
  };
}

/* Ikona w pasku.

   Każde `chrome.action.set*` każe Chrome przerysować pasek rozszerzeń.
   Wcześniej malowaliśmy przy KAŻDYM opublikowanym stanie — 18 razy na minutę,
   po trzy wywołania, mimo że napis na badge'u zmienia się raz na minutę.
   Efekt: migotanie ikon widoczne, gdy najedzie się na pasek rozszerzeń
   (zgłoszone 26.10.2026). Zmierzone w tests/badge.cjs: 54 wywołania/min
   przy jednej otwartej karcie, wszystkie z tą samą wartością.

   Dlatego malujemy TYLKO wtedy, gdy coś się faktycznie zmieniło. Po restarcie
   service workera pamięć znika i pierwsze malowanie idzie zawsze — i dobrze,
   bo wtedy nie wiemy, co jest na ikonie. */
let ostatniaIkona = null;

function badgeFor(snap) {
  if (!snap.settings.modTime) return { text: '', color: null, title: 'Calamari' };
  const unknown = snap.state === 'UNKNOWN';
  const text = unknown ? '!'
    : snap.state === 'STOPPED' ? (snap.dayWorkSeconds ? fmtShort(snap.dayWorkSeconds) : '')
    : snap.state === 'BREAK' ? '⏸' : fmtShort(snap.seconds);
  const color = unknown ? '#d12c48'
    : snap.state === 'BREAK' ? '#f7b91e' : snap.state === 'STOPPED' ? '#7f93a9' : '#21876e';
  const title = unknown ? 'Calamari — brak połączenia'
    : `Calamari — ${text || 'praca niezaczęta'}`;
  return { text, color, title };
}

async function paintBadge(snap) {
  snap ||= await snapshot();
  const chce = badgeFor(snap);
  const bylo = ostatniaIkona;
  if (bylo && bylo.text === chce.text && bylo.color === chce.color && bylo.title === chce.title) return;
  ostatniaIkona = chce;
  // Każde wywołanie osobno sprawdzane: przy samej zmianie minuty nie ma po co
  // ruszać koloru, a to też jest przerysowanie paska.
  if (!bylo || bylo.text !== chce.text) await chrome.action.setBadgeText({ text: chce.text });
  if (chce.color && (!bylo || bylo.color !== chce.color)) {
    await chrome.action.setBadgeBackgroundColor({ color: chce.color });
  }
  if (!bylo || bylo.title !== chce.title) await chrome.action.setTitle({ title: chce.title });
}

// Badge odświeżany alarmem. To jedyne zastosowanie chrome.alarms:
// NIE odmierza czasu (ten liczy się z znacznika startu), tylko odświeża napis.
chrome.alarms.create('paint', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'paint') broadcast().catch(() => {}); });

// Public reads wait for an in-flight write and its confirmation. An older
// read cannot overtake a completed action or replace its result in the UI.
async function readSnapshot(force = false) {
  if (writePending) {
    const result = await writePending;
    if (result.snap) return result.snap;
  }
  return snapshot(force);
}

let publishedRevision = 0;
async function publish(snap) {
  if (snap.revision <= publishedRevision) return;
  publishedRevision = snap.revision;
  chrome.runtime.sendMessage({ type: 'state', snap }).catch(() => {});
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (t.id) chrome.tabs.sendMessage(t.id, { type: 'state', snap }).catch(() => {});
  }
  await paintBadge(snap);
}
async function broadcast() { await publish(await readSnapshot()); }

/* Jedno miejsce reaguje na zmianę ustawień — bez względu na to, skąd przyszła:
   z opcji, z ikony, ze skrótu klawiszowego czy z synchronizacji storage.sync
   z drugiego komputera. Wcześniej odświeżenie wołał ręcznie każdy handler
   z osobna, więc ustawienie przyniesione przez synchronizację nie docierało
   nigdzie: worker podawał dalej ustawienia sprzed zmiany, a pigułka ukryta
   takim nieświeżym stanem przestawała o cokolwiek pytać i zostawała schowana
   do czasu powrotu do karty (znalezione 27.10.2026).

   Nasłuch budzi też uśpionego workera MV3, czyli dokładnie w tym stanie,
   w którym zwykle jest, gdy zmiana przychodzi z zewnątrz. */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'sync') return;
  /* pillPos zapisuje sama pigułka i uzgadnia go lokalnie (uzgodnionaPozycja
     w pill.js). Rozsyłanie go tutaj cofałoby widżet pod kursorem. */
  if (!Object.keys(changes).some(klucz => klucz !== 'pillPos')) return;
  invalidate();
  applyVariant().catch(() => {});
  broadcast().catch(() => {});
});

const EXPECTED_STATE = { clockIn: 'WORKING', clockOut: 'STOPPED', breakStart: 'BREAK', breakStop: 'WORKING' };
async function performAction(type, project) {
  if (writePending) return { ok: false, kind: 'AKCJA_TRWA', reason: 'Poprzednia akcja jest jeszcze synchronizowana.' };
  const job = (async () => {
    invalidate();
    const result = await Api[type](project); // exactly one write, including on timeout
    invalidate();
    const confirmationStarted = Date.now();
    let snap = await snapshot(false, true);
    // A 204 acknowledges the write, but the clock read can briefly lag behind.
    // Repeat only the read, never clock-in/out. Keep all action buttons locked.
    for (let attempt = 0; result.ok && snap.state !== 'UNKNOWN' &&
         snap.state !== EXPECTED_STATE[type] && Date.now() - confirmationStarted < 2000 && attempt < 2; attempt++) {
      await new Promise(resolve => setTimeout(resolve, 400));
      snap = await snapshot(true, true);
    }
    await publish(snap);
    if (result.ok && snap.state !== EXPECTED_STATE[type]) {
      return { ok: false, kind: 'BRAK_POTWIERDZENIA', snap,
        reason: 'Zapis został przyjęty, ale nie udało się jeszcze potwierdzić nowego stanu zegara. Sprawdź stan w Calamari.' };
    }
    return { ...result, snap };
  })();
  writePending = job;
  try { return await job; }
  finally { if (writePending === job) writePending = null; }
}

/* -------------------------------------------------------------- wiadomości */

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg?.type === 'state') return false;
  // Odpowiedź ma przyjść ZAWSZE — także gdy coś rzuci wyjątkiem albo zawiśnie.
  // Inaczej panel, pigułka i diagnostyka czekają w nieskończoność na „Sprawdzam…".
  let answered = false;
  const answer = v => { if (!answered) { answered = true; try { reply(v); } catch (e) {} } };
  const guard = setTimeout(() => answer({ ok: false, error: 'service worker nie odpowiedział w 20 s', type: msg && msg.type }), 20000);
  (async () => {
    try {
    switch (msg.type) {
      case 'get': {
        const snap = await readSnapshot(!!msg.force);
        answer(snap);
        await publish(snap);
        break;
      }

      case 'clockIn': case 'clockOut': case 'breakStart': case 'breakStop':
        answer(await performAction(msg.type, msg.type === 'breakStart' ? msg.breakType : msg.project)); break;

      /* Przypisanie projektu to osobne żądanie, nie część clock-in.
         Po zapisie unieważniamy cache i rozsyłamy nowy stan, żeby panel
         i pigułka pokazały projekt potwierdzony przez serwer, a nie wybrany lokalnie. */
      case 'setProject': {
        const r = await Api.switchProject(msg.projectId, !!msg.fromBeginning);
        invalidate();
        answer(r);
        broadcast().catch(() => {});
        break;
      }

      /* Unieważnienie i rozesłanie stanu robi nasłuch storage.onChanged —
         tu zostaje tylko to, czego zapis nie pociąga za sobą sam z siebie.
         applyVariant wołamy mimo to przed odpowiedzią, żeby opcje dostały
         „ok" dopiero wtedy, gdy zachowanie panelu jest już przestawione. */
      case 'setSettings':
        await chrome.storage.sync.set(msg.patch);
        await applyVariant();
        answer({ ok: true }); break;

      case 'hidePill':
        await chrome.storage.sync.set({ pillHidden: true });
        answer({ ok: true }); break;

      case 'savePos':
        await chrome.storage.sync.set({ pillPos: msg.pos });
        answer({ ok: true }); break;

      case 'openWindow':  await openFloatingWindow(); answer({ ok: true }); break;
      case 'openLogin':   answer(await openLogin()); break;
      case 'reinject':    await reinjectAll(); answer({ ok: true }); broadcast().catch(() => {}); break;
      case 'toggleWidget': answer(await toggleWidget()); break;
      case 'diagnose':    answer(await Api.diagnose()); break;
      case 'pageTest':    answer(await pageTransportTest()); break;
      case 'transportTest': answer(await transportTest()); break;
      // Sonda wniosku urlopowego: start, odczyt, zatrzymanie, czyszczenie.
      // 'probeLog' przychodzi z mostu w ramce przy każdym przechwyconym żądaniu.
      case 'probeStart':  answer(await probeStart()); break;
      case 'probeStop':   answer(await probeStop()); break;
      case 'probeRead':   answer(await probeRead()); break;
      case 'probeClear':  answer(await probeClear()); break;
      case 'probeLog':    await probeAppend(msg.entry); answer({ ok: true }); break;
      // Formularz wniosku — definicja pól i dane pomocnicze idą z serwera.
      case 'absenceTypes':   answer(await Api.absenceTypes()); break;
      case 'partDay':        answer(await Api.partDay(msg.req)); break;
      case 'employees':      answer(await Api.employees(msg.query)); break;
      case 'validateRequest':answer(await Api.validateRequest(msg.req)); break;
      case 'submitRequest':  answer(await Api.submitRequest(msg.req)); invalidate(); broadcast().catch(() => {}); break;
      case 'resetMock':   await Api.resetMock(); invalidate(); answer({ ok: true }); broadcast().catch(() => {}); break;

      default: answer({ ok: false, error: 'nieznany typ ' + msg.type });
    }
    } catch (e) {
      answer({ ok: false, error: String(e && e.message || e), type: msg && msg.type });
    } finally { clearTimeout(guard); }
  })();
  return true;   // odpowiedź asynchroniczna
});

/* ----------------------------------------------------- warianty interfejsu */

let floatingWindowId = null;

async function openFloatingWindow() {
  if (floatingWindowId !== null) {
    try { await chrome.windows.update(floatingWindowId, { focused: true }); return; }
    catch (e) { floatingWindowId = null; }
  }
  const w = await chrome.windows.create({
    url: chrome.runtime.getURL('ui/panel.html?host=window'),
    type: 'popup', width: 340, height: 560, top: 90, left: 1040
  });
  floatingWindowId = w.id;
}
chrome.windows.onRemoved.addListener(id => { if (id === floatingWindowId) floatingWindowId = null; });

/* ---------------------------------------------------------------- logowanie

   Świadomie NIE zbieramy hasła w rozszerzeniu. Logowanie otwieramy na
   prawdziwej stronie Calamari w małym oknie: działa SSO (Slack, Google,
   Microsoft, SAML), działa menedżer haseł, widać pasek adresu, a rozszerzenie
   nigdy nie dotyka danych logowania.

   Po zalogowaniu nie trzeba nic klikać — nasłuchujemy ciasteczek Calamari
   i gdy sesja wróci, odświeżamy stan i zamykamy okno logowania. */
let loginWindowId = null;

async function openLogin() {
  if (loginWindowId !== null) {
    try { await chrome.windows.update(loginWindowId, { focused: true }); return { ok: true }; }
    catch (e) { loginWindowId = null; }
  }
  const w = await chrome.windows.create({
    url: 'https://app-new.calamari.io/', type: 'popup', width: 560, height: 760, top: 80, left: 420
  });
  loginWindowId = w.id;
  return { ok: true };
}
chrome.windows.onRemoved.addListener(id => { if (id === loginWindowId) loginWindowId = null; });

let cookieTimer = null;
chrome.cookies.onChanged.addListener(info => {
  const domain = (info.cookie && info.cookie.domain || '').replace(/^\./, '');
  if (!domain.endsWith('calamari.io')) return;
  clearTimeout(cookieTimer);
  cookieTimer = setTimeout(async () => {
    invalidate();
    let snap = null;
    try { snap = await readSnapshot(true); } catch (e) {}
    broadcast().catch(() => {});
    // Sesja wróciła i to my otworzyliśmy okno logowania — sprzątamy po sobie.
    if (snap && snap.diag && snap.diag.live && loginWindowId !== null) {
      try { await chrome.windows.remove(loginWindowId); } catch (e) {}
      loginWindowId = null;
    }
  }, 1200);
});

async function applyVariant() {
  const s = await settings();
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: s.variant === 'sidepanel' });
  } catch (e) {}
}

/* Jedno przełączanie widżetu dla ikony i skrótu klawiszowego.
   Wcześniej ikona tylko pokazywała (ustawiała pillHidden: false), a skrót
   przełączał — dwie drogi robiły co innego. Teraz obie wołają to samo. */
async function toggleWidget() {
  const s = await settings();

  /* Wariant B. Wcześniej skrót przestawiał tu `pillHidden` — flagę pigułki,
     której w side panelu nie ma, czyli udawał, że coś robi.

     SPRAWDZONE U UŻYTKOWNIKA 27.10.2026: poniższe `sidePanel.open()` też nie
     otwiera panelu. Najpewniej dlatego, że Chrome wymaga do tego gestu
     użytkownika, a zużywają go `await` powyżej (settings, tabs.query).
     Gdyby kiedyś wrócić do tematu: trzeba wołać `open()` jako pierwszą rzecz
     w obsłudze komendy, przed jakimkolwiek await.

     Sebastian uznał, że w wariancie B skrót nie jest potrzebny. Zostawiamy
     próbę, bo nic nie psuje, a zwraca `shown: false` z powodem zamiast
     cicho kłamać. Chrome i tak nie daje API do ZAMYKANIA panelu. */
  if (s.variant === 'sidepanel') {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.windowId != null) await chrome.sidePanel.open({ windowId: tab.windowId });
      return { shown: true, variant: s.variant };
    } catch (e) {
      return { shown: false, variant: s.variant, reason: String(e.message || e) };
    }
  }

  if (s.variant === 'window') {
    let open = false;
    if (floatingWindowId !== null) {
      try { await chrome.windows.get(floatingWindowId); open = true; }
      catch (e) { floatingWindowId = null; }
    }
    if (open) {
      try { await chrome.windows.remove(floatingWindowId); } catch (e) {}
      floatingWindowId = null;
      return { shown: false, variant: s.variant };
    }
    await openFloatingWindow();
    return { shown: true, variant: s.variant };
  }

  const hidden = !s.pillHidden;          // było widoczne → chowamy, i odwrotnie
  await chrome.storage.sync.set({ pillHidden: hidden });
  if (!hidden) reinjectAll().catch(() => {});   // reszta: nasłuch storage.onChanged
  return { shown: !hidden, variant: s.variant };
}

chrome.action.onClicked.addListener(() => { toggleWidget().catch(() => {}); });

// Wystawione dla testów: inaczej nie da się sprawdzić zachowania skrótu
// w wariancie B bez symulowania naciśnięcia klawiszy w Chrome.
globalThis.__toggleWidgetForTest = () => toggleWidget();

chrome.commands.onCommand.addListener(cmd => {
  if (cmd === 'toggle-pill') toggleWidget().catch(() => {});
});

/* Content script z manifestu nie zadziała na kartach otwartych PRZED instalacją
   lub aktualizacją — tam zostaje sierota ze starej wersji. Dowstrzykujemy nową.
   Ten sam problem i to samo obejście co u ClickUpa (popup.js → chrome.scripting).
   Funkcja jest deklaracją, więc jest podniesiona i widoczna dla listenera wyżej. */
async function reinjectAll() {
  let tabs = [];
  try { tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }); } catch (e) { return; }
  await Promise.allSettled(tabs.map(t => ensurePill(t.id)));
}

const pillChecks = new Map();
function ensurePill(tabId) {
  if (pillChecks.has(tabId)) return pillChecks.get(tabId);
  const job = (async () => {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (!/^https?:\/\//.test(tab.url || '') || tab.discarded || tab.frozen) return;
      const s = await settings();
      if (s.variant !== 'pill' || s.pillHidden || !(s.modTime || s.modLeave)) return;
      try {
        const pong = await Promise.race([
          chrome.tabs.sendMessage(tabId, { type: 'pillPing' }),
          new Promise(resolve => setTimeout(() => resolve(null), 700))
        ]);
        if (pong?.ok) return;
      } catch (e) {}
      await chrome.scripting.executeScript({ target: { tabId }, injectImmediately: true, files: ['content/pill.js'] });
    } catch (e) { /* Restricted browser pages and tabs closed during the check. */ }
  })();
  pillChecks.set(tabId, job);
  job.finally(() => { if (pillChecks.get(tabId) === job) pillChecks.delete(tabId); });
  return job;
}

chrome.tabs.onActivated.addListener(({ tabId }) => { ensurePill(tabId); });
chrome.tabs.onUpdated.addListener((tabId, change) => {
  if (change.status === 'complete' || change.discarded === false || change.frozen === false) ensurePill(tabId);
});
chrome.windows.onFocusChanged.addListener(async windowId => {
  if (windowId < 0) return;
  try {
    const tabs = await chrome.tabs.query({ active: true, windowId });
    for (const tab of tabs) ensurePill(tab.id);
  } catch (e) {}
});

chrome.runtime.onInstalled.addListener(async () => {
  await applyVariant();
  await reinjectAll();
  paintBadge().catch(() => {});
  invalidate(); broadcast().catch(() => {});
});
chrome.runtime.onStartup.addListener(() => {
  applyVariant();
  reinjectAll().catch(() => {});
  invalidate(); broadcast().catch(() => {});
});

applyVariant();
paintBadge().catch(() => {});
