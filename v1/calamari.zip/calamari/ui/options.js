const $ = id => document.getElementById(id);

// Strona opcji też przeżywa przeładowanie rozszerzenia jako sierota.
function alive() {
  try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}
async function send(m) {
  if (!alive()) { note('Rozszerzenie zostało przeładowane. Odśwież tę stronę.'); return null; }
  try {
    return await chrome.runtime.sendMessage(m);
  } catch (e) {
    note('Rozszerzenie zostało przeładowane. Odśwież tę stronę.');
    return null;
  }
}
function note(txt) {
  const out = $('probeOut');
  if (out) { out.classList.remove('hidden'); out.textContent = txt; }
}

// Strony rozszerzenia nie odświeżają się po przeładowaniu go w chrome://extensions.
// Bez tego łatwo klikać w starym interfejsie i dziwić się, że nic się nie zmieniło.
(function showVersion() {
  try {
    const m = chrome.runtime.getManifest();
    $('ver').textContent = 'v' + m.version;
  } catch (e) {
    $('ver').textContent = 'odłączona';
    $('stale').classList.remove('hidden');
  }
})();

async function load() {
  const s = await chrome.storage.sync.get(['variant', 'modLeave', 'modTime', 'dataMode', 'tenant', 'pillHidden', 'lang']);
  const variant = s.variant || 'pill';
  const dataMode = s.dataMode || 'live';
  // Stan zaznaczenia musi iść do aria-checked, nie tylko do klasy CSS —
  // czytnik ekranu nie widzi koloru obramowania.
  const mark = (el, on) => { el.classList.toggle('on', on); el.setAttribute('aria-checked', String(on)); };
  document.querySelectorAll('.opt[data-v]').forEach(o => mark(o, o.dataset.v === variant));
  document.querySelectorAll('.opt[data-d]').forEach(o => mark(o, o.dataset.d === dataMode));
  if (s.tenant) $('tenant').value = s.tenant;
  document.querySelectorAll('.tg[data-m]').forEach(t => {
    const v = s[t.dataset.m];
    mark(t, v === undefined ? true : !!v);
  });
  document.querySelectorAll('.tg[data-l]').forEach(e => mark(e, (s.lang || '') === e.dataset.l));

  const m = await chrome.storage.local.get('mockState');
  const blocked = m.mockState && m.mockState.available === false;
  $('blockBtn').textContent = blocked ? 'Odblokuj rejestrację' : 'Zablokuj rejestrację (restrykcja IP)';

  const NAZWA = { pill: 'A — pigułka na stronie', sidepanel: 'B — badge i side panel', window: 'C — osobne okno' };
  const mods = [];
  if (s.modLeave !== false) mods.push('Nieobecności');
  if (s.modTime !== false) mods.push('Czas pracy');
  const hidden = s.pillHidden === true;
  const d = await chrome.storage.local.get('diag');
  const diag = d.diag || {};
  const zrodlo = diag.live
    ? (diag.transport === 'page'
        ? 'na żywo, przez otwartą kartę Calamari'
        : 'na żywo, bez karty')
    : (diag.kind === 'TRYB_ATRAPY' ? 'atrapa (wybrana ręcznie)' : 'brak połączenia — ' + (diag.kind || 'nieznany powód'));

  $('statusLine').innerHTML =
    `Wariant: <b>${NAZWA[variant] || variant}</b> · ` +
    `Pigułka: <b>${variant !== 'pill' ? 'nieaktywna w tym wariancie' : hidden ? 'SCHOWANA' : 'widoczna'}</b> · ` +
    `Moduły: <b>${mods.join(' + ') || 'żaden'}</b><br>Dane: <b>${zrodlo}</b>`;
}

$('showBtn').onclick = async () => {
  await send({ type: 'setSettings', patch: { variant: 'pill', pillHidden: false, modLeave: true, modTime: true } });
  await send({ type: 'reinject' });   // żeby nie trzeba było odświeżać kart
  load();
};

$('pageBtn').onclick = async () => {
  const out = $('probeOut');
  out.classList.remove('hidden');
  out.textContent = 'Testuję kartę Calamari…';
  $('pageBtn').disabled = true;
  try {
    const r = await send({ type: 'pageTest' });
    if (!r) { out.textContent = 'Brak odpowiedzi z rozszerzenia.'; return; }
    const lines = [`Karta: ${r.tab || '—'} · ID ${r.tabId || '—'}`];
    if (r.ping) lines.push(`Uruchomienie skryptu: ${r.pingMs} ms · ${r.ping.origin} · stan strony ${r.ping.readyState}`);
    lines.push(r.ok ? `✅ Calamari odpowiedziało w ${r.callMs} ms · stan ${r.state} · czas serwera ${r.now}`
      : `❌ ${r.kind || ''} · ${r.detail || r.error || 'Brak szczegółów'}`);
    out.textContent = lines.join('\n');
  } finally { $('pageBtn').disabled = false; }
};

$('transportBtn').onclick = async () => {
  const out = $('probeOut');
  out.classList.remove('hidden');
  out.textContent = 'Sprawdzam, czy da się bez karty…';
  $('transportBtn').disabled = true;
  try {
    const r = await send({ type: 'transportTest' });
    if (!r) { out.textContent = 'Brak odpowiedzi z rozszerzenia.'; return; }
    if (!r.ok) { out.textContent = r.detail || 'Nie udało się sprawdzić.'; return; }
    const L = [];
    L.push(r.mode === 'direct'
      ? `✅ Karta NIE jest potrzebna (${r.ms} ms).`
      : `⚠️ Karta Calamari jest potrzebna (${r.ms} ms).`);
    L.push(r.mode === 'direct'
      ? 'Rozszerzenie rozmawia z Calamari wprost. Możesz zamknąć wszystkie karty aplikacji.'
      : 'Bezpośrednie żądanie nie przeszło — widżet wraca do wysyłania przez otwartą kartę.');
    L.push('');
    L.push(`Konto: ${r.host}`);
    if (r.ciasteczka && r.ciasteczka.length) {
      L.push('Ciasteczka sesji:');
      for (const c of r.ciasteczka) {
        L.push(`  ${c.name} · SameSite=${c.sameSite || 'brak'}` +
               `${c.httpOnly ? ' · httpOnly' : ''}${c.secure ? ' · secure' : ''}`);
      }
      // SameSite to najczęstsza przyczyna, dla której bezpośrednio się nie da.
      if (r.mode !== 'direct' && r.ciasteczka.some(c => /strict|lax/i.test(c.sameSite || ''))) {
        L.push('');
        L.push('Ciasteczko sesji ma SameSite, więc nie leci z żądaniem spoza witryny.');
        L.push('Tego nie obejdzie żadna sztuczka po stronie rozszerzenia — to pytanie do dev teamu.');
      }
    }
    out.textContent = L.join('\n');
  } finally { $('transportBtn').disabled = false; }
};

const absOut = txt => { const e = $('absOut'); e.classList.remove('hidden'); e.textContent = txt; };

$('probeOn').onclick = async () => {
  absOut('Włączam nasłuch i przeładowuję ramkę wniosków…');
  const r = await send({ type: 'probeStart' });
  absOut(!r ? 'Brak odpowiedzi z rozszerzenia.'
    : r.ok ? `Nasłuch włączony na karcie ${r.tab}.\n\nTeraz wypełnij i wyślij wniosek w Calamari, potem wróć i kliknij „Pokaż przechwycone".`
           : '❌ ' + (r.detail || 'nie udało się włączyć'));
};

$('probeShow').onclick = async () => {
  const r = await send({ type: 'probeRead' });
  if (!r) { absOut('Brak odpowiedzi z rozszerzenia.'); return; }
  const e = r.entries || [];
  if (!e.length) { absOut('Nic nie przechwycono. Czy nasłuch był włączony przed wysłaniem wniosku?'); return; }
  const L = [`Przechwycono ${e.length} żądań:`, ''];
  for (const q of e) {
    L.push(`[${q.at}] ${q.kind.toUpperCase()} ${q.method} ${String(q.url).replace(/^https?:\/\/[^/]+/, '')}` +
           (q.status != null ? `  → ${q.status}` : ''));
    if (q.body) L.push(`     wysłano:  ${q.body}`);
    if (q.text) L.push(`     odpowiedź: ${q.text}`);
  }
  absOut(L.join('\n'));
};

$('probeOff').onclick = async () => {
  await send({ type: 'probeStop' });
  await send({ type: 'probeClear' });
  absOut('Nasłuch wyłączony, przechwycone dane wyczyszczone.');
};

$('factoryBtn').onclick = async () => {
  try { await chrome.storage.sync.clear(); } catch (e) {}
  await send({ type: 'setSettings', patch: { variant: 'pill', pillHidden: false, modLeave: true, modTime: true, dataMode: 'live' } });
  await send({ type: 'reinject' });
  load();
};

/* Grupy radio obsługują strzałki: w radiogroup Tab wchodzi do grupy, a wybór
   zmienia się strzałkami (WAI-ARIA APG). Bez tego klawiatura widzi trzy
   osobne przyciski i nie wie, że to jeden wybór. */
function wireArrows(sel) {
  const items = Array.from(document.querySelectorAll(sel));
  items.forEach((el, i) => el.addEventListener('keydown', e => {
    const d = { ArrowDown: 1, ArrowRight: 1, ArrowUp: -1, ArrowLeft: -1 }[e.key];
    if (!d) return;
    e.preventDefault();
    const next = items[(i + d + items.length) % items.length];
    next.focus(); next.click();
  }));
}
wireArrows('.opt[data-v]');
wireArrows('.opt[data-d]');
wireArrows('.tg[data-l]');

document.querySelectorAll('.opt[data-v]').forEach(o => o.addEventListener('click', async () => {
  document.querySelectorAll('.opt[data-v]').forEach(x => {
    x.classList.remove('on'); x.setAttribute('aria-checked', 'false');
  });
  o.classList.add('on'); o.setAttribute('aria-checked', 'true');
  await send({ type: 'setSettings', patch: { variant: o.dataset.v, pillHidden: false } });
  if (o.dataset.v === 'window') send({ type: 'openWindow' });
}));

document.querySelectorAll('.opt[data-d]').forEach(o => o.addEventListener('click', async () => {
  document.querySelectorAll('.opt[data-d]').forEach(x => {
    x.classList.remove('on'); x.setAttribute('aria-checked', 'false');
  });
  o.classList.add('on'); o.setAttribute('aria-checked', 'true');
  await send({ type: 'setSettings', patch: { dataMode: o.dataset.d } });
}));

document.querySelectorAll('.tg[data-l]').forEach(e => e.addEventListener('click', async () => {
  document.querySelectorAll('.tg[data-l]').forEach(x => {
    x.classList.remove('on'); x.setAttribute('aria-checked', 'false');
  });
  e.classList.add('on'); e.setAttribute('aria-checked', 'true');
  await send({ type: 'setSettings', patch: { lang: e.dataset.l } });
}));

document.querySelectorAll('.tg[data-m]').forEach(t => t.addEventListener('click', async () => {
  const on = !t.classList.contains('on');
  t.classList.toggle('on', on);
  t.setAttribute('aria-checked', String(on));
  await send({ type: 'setSettings', patch: { [t.dataset.m]: on } });
}));

$('blockBtn').onclick = async () => {
  const m = await chrome.storage.local.get('mockState');
  const cur = m.mockState || {};
  const next = cur.available === false;
  await chrome.storage.local.set({
    mockState: { ...cur, available: next, reason: next ? 'NONE' : 'IP_RESTRICTION' }
  });
  await send({ type: 'setSettings', patch: {} });   // wymusza broadcast
  load();
};

$('resetBtn').onclick = async () => { await send({ type: 'resetMock' }); load(); };

$('probeBtn').onclick = async () => {
  const out = $('probeOut');
  out.classList.remove('hidden');
  out.textContent = 'Sprawdzam…';
  const typed = $('tenant').value.trim().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
  if (typed) await send({ type: 'setSettings', patch: { tenant: typed } });
  const r = await send({ type: 'diagnose' });
  if (!r || r.ok === false) { out.textContent = r?.error || 'Brak odpowiedzi z rozszerzenia.'; return; }
  const lines = [];
  lines.push(`Origin rozszerzenia: chrome-extension://${chrome.runtime.id}`);
  lines.push(`Najemca: ${r.tenant || '—'}`);
  lines.push('');
  for (const st of (r.steps || [])) {
    lines.push(`${st.ok ? '✅' : '❌'} ${st.step}`);
    if (st.detail) lines.push(`   ${st.detail}`);
  }
  if (r.sample && r.sample.plan) {
    const d = r.sample.plan;
    lines.push('');
    lines.push(`Plan dnia z serwera: ${d.start || '—'} – ${d.end || '—'}`);
  }
  out.textContent = lines.join('\n');
  if (typed) $('tenant').value = typed;
};

load();
