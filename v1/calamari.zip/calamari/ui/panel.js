import { fmtHms, allowedBreakTypes, localISODate } from '../lib/api.js';
import { makeT, normalizeLang } from '../lib/i18n.js';

const host = new URLSearchParams(location.search).get('host') || 'panel';
document.body.classList.add('host-' + host);

const $ = id => document.getElementById(id);

let snap = null, ticker = null, dead = false, poller = null, refreshing = null;
let t = makeT('pl');   // podmieniany na język konta po pierwszym odczycie

/* Po przeładowaniu rozszerzenia stary kontekst umiera, a każde sięgnięcie do
   chrome.runtime rzuca „Extension context invalidated". Wykrywamy to i cicho
   zamykamy panel zamiast sypać błędami w konsolę. */
function alive() {
  try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
}
function teardown(msg) {
  if (dead) return;
  dead = true;
  if (ticker) clearInterval(ticker);
  if (poller) clearInterval(poller);
  document.body.innerHTML =
    '<div class="empty">' + (msg || 'Rozszerzenie zostało przeładowane.<br>Odśwież stronę.') + '</div>';
}
async function send(msg) {
  if (dead) return null;
  if (!alive()) { teardown(); return null; }
  try {
    return await chrome.runtime.sendMessage(msg);
  } catch (e) {
    if (/context invalidated/i.test(String(e))) teardown();
    return null;
  }
}

/* ----------------------------------------------------------------- render */

function applyStaticTexts() {
  for (const el of document.querySelectorAll('[data-i18n]')) el.textContent = t(el.dataset.i18n);
  // Czytnik ekranu dobiera syntezę mowy po atrybucie lang. Bez tego polskie
  // teksty są czytane angielskim głosem i są niezrozumiałe.
  document.documentElement.lang = t.lang;
  $('reqForm').setAttribute('aria-label', t('request'));
  $('mineEye').textContent = t('a11yUpcoming');
}

function render(s) {
  if (snap && (s.epoch < snap.epoch || (s.epoch === snap.epoch && s.revision < snap.revision))) return;

  // Język bierzemy z ustawień konta Calamari; opcje mogą go nadpisać.
  const want = normalizeLang((s.settings && s.settings.lang) || (s.me && s.me.lang) || 'pl');
  if (want !== t.lang) { t = makeT(want); applyStaticTexts(); }

  // Wylogowanie to nie usterka — zamiast komunikatu o błędzie pokazujemy jeden krok.
  const loggedOut = s.diag && !s.diag.live && s.diag.kind === 'WYLOGOWANY';
  $('signin').classList.toggle('hidden', !loggedOut);
  $('root').classList.toggle('hidden', loggedOut);
  if (loggedOut) { $('conn').classList.add('hidden'); snap = s; return; }
  s._renderedAt = s.sampledAt || Date.now();
  snap = s;
  const set = s.settings;
  const any = set.modTime || set.modLeave;

  renderConn(s.diag);
  $('empty').classList.toggle('hidden', any);
  $('s-time').classList.toggle('hidden', !set.modTime);
  $('s-leave').classList.toggle('hidden', !set.modLeave);
  // „Dzisiaj nieobecni" należy do modułu Nieobecności. Pokazywaniem steruje
  // renderLeave(), ale ta leci tylko przy włączonym module — bez tej linii
  // sekcja zostawała na ekranie ze starymi danymi po jego wyłączeniu.
  if (!set.modLeave) $('s-who').classList.add('hidden');

  if (set.modTime) renderTime(s);
  if (set.modLeave) renderLeave(s);

  // Najemca jest w pasku u góry — w stopce pokazujemy człowieka, nie adres.
  $('whoami').textContent = (s.me.fullName || `${s.me.firstName || ''} ${s.me.lastName || ''}`).trim();
  startTicker();
}

const KIND_TXT = {
  BRAK_NAJEMCY:  'Nie wykryto konta Calamari',
  BRAK_SESJI:    'Nie jesteś zalogowany w Calamari',
  SESJA_WYGASLA: 'Sesja wygasła',
  ZABLOKOWANE:   'Backend odrzucił żądanie z rozszerzenia',
  ODRZUCONY_ORIGIN: 'Backend odrzucił origin rozszerzenia',
  ZABRONIONE:    'Backend odmówił (403)',
  BRAK_KARTY:    'Otwórz kartę Calamari',
  WYLOGOWANY:    'Nie jesteś zalogowany w Calamari',
  KARTA_USPIONA: 'Karta Calamari uśpiona przez przeglądarkę',
  KARTA_ODMOWILA:'Karta Calamari nie odpowiedziała',
  BLAD_HTTP:     'Błąd odpowiedzi',
  TRYB_ATRAPY:   'Tryb atrapy',
  BLAD:          'Błąd'
};

function renderConn(diag) {
  const el = $('conn');
  // Działające połączenie nie jest informacją — same dane są dowodem, że działa.
  // Pasek pokazujemy wyłącznie wtedy, gdy coś jest nie tak.
  if (!diag || diag.live) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  $('connKind').textContent = KIND_TXT[diag.kind] || 'Brak połączenia';
  $('connDetail').textContent = diag.kind === 'TRYB_ATRAPY'
    ? 'przełącz w opcjach' : (diag.detail || 'Nie udało się pobrać danych z Calamari');
}

function renderTime(s) {
  const st = s.state;
  // etykiety przycisków akcji zależą od języka
  const btn = { bStart: 'start', bStop: 'stop', bStop2: 'stop', bBreak: 'breakBtn', bBreakEnd: 'resume' };
  for (const [id, key] of Object.entries(btn)) {
    const e = $(id); if (!e) continue;
    const label = e.querySelector('svg') ? e.childNodes[e.childNodes.length - 1] : null;
    if (label && label.nodeType === 3) label.nodeValue = t(key); else e.textContent = t(key);
  }
  if (!s.screen) {
    for (const id of ['actsStopped', 'actsWorking', 'actsBreak', 'projWrap', 'breakChoice', 'noBreaks']) $(id).classList.add('hidden');
    $('timeEye').textContent = t('noData');
    $('big').textContent = '—';
    $('bigSub').textContent = t('checkConn');
    $('planTxt').textContent = '—';
    $('track').innerHTML = ''; $('trkA').textContent = ''; $('trkB').textContent = '';
    $('trkSum').textContent = ''; tl = null;
    $('blocked').classList.toggle('hidden', !lastError);
    if (lastError) $('blocked').innerHTML = lastError;
    return;
  }
  $('actsStopped').classList.toggle('hidden', st !== 'STOPPED');
  $('actsWorking').classList.toggle('hidden', st !== 'WORKING');
  $('actsBreak').classList.toggle('hidden', st !== 'BREAK');
  // Dropdown jest widoczny ZAWSZE, gdy są projekty — projekt przełącza się
  // także w trakcie pracy, a nie tylko przed startem.
  $('projWrap').classList.toggle('hidden', !(s.screen.activeProjects || []).length);

  $('timeEye').textContent =
    actionPending ? t('syncing') : st === 'WORKING' ? t('working') : st === 'BREAK' ? t('onBreak')
    : (s.dayWorkSeconds ? t('finished') : t('notStarted'));
  $('big').classList.toggle('paused', st === 'BREAK');

  const d = s.screen.dayOfWorkingWeek;
  $('planTxt').textContent = (d && d.workingDay)
    ? `${d.start.slice(0, 5)} – ${d.end.slice(0, 5)} / ${Math.round(d.seconds / 3600)}h`
    : t('dayOff');
  renderTimeline(s);

  // Błąd ostatniej akcji jest lepki: nie może zniknąć przy najbliższym odświeżeniu,
  // bo wtedy pracownik nie zdąży go przeczytać i nie wie, że nic się nie zapisało.
  const blocked = !s.avail.available;
  for (const id of ['bStart', 'bStop', 'bStop2', 'bBreak', 'bBreakEnd']) $(id).disabled = blocked || actionPending;
  renderBreaks(s, blocked);
  if (lastError) {
    $('blocked').classList.remove('hidden');
    $('blocked').innerHTML = lastError;
  } else {
    $('blocked').classList.toggle('hidden', !blocked);
    if (blocked) $('blocked').textContent =
      `Nie możesz tu rozpocząć pracy. Powód zgłoszony przez Calamari: ${s.avail.reason}.`;
  }
  $('bStart').disabled = blocked || actionPending;

  renderProjects(s);
  paintClock();
}

function renderBreaks(s, blocked) {
  const types = allowedBreakTypes(s.screen);
  const select = $('breakType');
  const previous = select.value;
  const options = (types.length > 1 ? `<option value="">${esc(t('chooseBreak'))}</option>` : '') +
    types.map(b => `<option value="${esc(String(b.id))}">${esc(b.name)}</option>`).join('');
  // Preserve focus and the selection across periodic snapshots.
  if (select.dataset.options !== options) {
    select.innerHTML = options;
    select.dataset.options = options;
    if (types.some(b => String(b.id) === previous)) select.value = previous;
  }
  $('breakChoice').classList.toggle('hidden', s.state !== 'WORKING' || types.length < 2);
  $('noBreaks').classList.toggle('hidden', s.state !== 'WORKING' || types.length > 0);
  $('bBreak').disabled = blocked || actionPending || !types.length || !select.value;
  select.disabled = blocked || actionPending;
}

/* Etykieta licznika dla czytnika ekranu.

   Widoczne „2:14:33" czytnik przeczyta albo jako trzy osobne liczby, albo jako
   godzinę zegarową („za kwadrans trzecia") — i jedno, i drugie jest mylące.
   Stąd osobna etykieta słowna. Odświeżamy ją tylko wtedy, gdy zmieni się
   minuta: aria-label zmieniany 60 razy na minutę potrafi zapętlić czytnik. */
let lastTimerLabel = '';
function setTimerLabel(stateWord, seconds) {
  const label = `${t('a11yTimer')}: ${stateWord}, ${t.dur(seconds)}`;
  if (label === lastTimerLabel) return;
  lastTimerLabel = label;
  $('big').setAttribute('aria-label', label);
}

function paintClock() {
  if (!snap || !snap.settings.modTime || !snap.screen) return;
  const st = snap.state;
  if (st === 'STOPPED') {
    // Po zakończeniu pracy Calamari pokazuje sumę dnia, nie zero — robimy tak samo.
    const day = snap.dayWorkSeconds || 0;
    const h = Math.floor(day / 3600), m = Math.floor(day % 3600 / 60), x = day % 60;
    $('big').textContent = `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}`;
    setTimerLabel(day ? t('a11yStateFinished') : t('a11yStateStopped'), day);
    const n = (snap.screen.dayShifts || []).length;
    // odmiana przez lib/i18n — „16 zmiany" z 0.6.1 brało się z braku tej reguły
    $('bigSub').textContent = n ? `${t.n(n, 'shift')} ${t('totalWorked')}` : t('clickToStart');
    tickTimeline();
    renderSummary(snap, 0);
    return;
  }
  const drift = Math.max(0, Math.floor((Date.now() - snap._renderedAt) / 1000));
  const sec = snap.seconds + drift;

  // ten sam format co pigułka
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
  $('big').textContent = `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}`;
  setTimerLabel(st === 'BREAK' ? t('a11yStateBreak') : t('a11yStateWorking'), sec);

  const startMs = st === 'BREAK' ? snap.screen._breakStartedMs : snap.screen._startedTimeMs;
  const start = startMs != null ? new Date(startMs) : null;
  $('bigSub').textContent = start
    ? `${st === 'BREAK' ? t('breakFrom') : t('startedAt')} ${String(start.getHours()).padStart(2, '0')}:${String(start.getMinutes()).padStart(2, '0')}`
    : '';

  tickTimeline();
  renderSummary(snap, drift);
}

function renderLeave(s) {
  const a = s.absence;
  // Zapis wniosku działa też na żywo od 0.6.0 — przycisk blokujemy tylko bez danych.
  $('bRequest').disabled = !a;
  if (!a) $('reqForm').classList.add('hidden');
  // etykieta zależy i od stanu formularza, i od języka — ustawiamy ją zawsze
  const formOpen = !$('reqForm').classList.contains('hidden');
  $('bRequest').textContent = formOpen ? t('hideForm') : t('request');
  $('bRequest').setAttribute('aria-expanded', String(formOpen));
  if (!a) {
    $('lim').textContent = t('noLimits');
    $('mine').textContent = '';
    $('mineEye').classList.add('hidden');
    $('s-who').classList.add('hidden');
    return;
  }

  // Kafelek „12 / urlopu wypoczynkowego" wzrokowo czyta się jako całość,
  // ale czytnik ekranu dostaje dwa oderwane fragmenty. Stąd aria-label
  // na pozycji listy i ukrycie rozbitych kawałków przed czytnikiem.
  /* Wszystkie typy z saldem, jeden wiersz na typ.
     Kafelki z wielką liczbą mieściły dwa i ukrywały resztę — na koncie
     testowym pracownik ma ich siedem. Wiersz nazwa-wartość skaluje się
     na dowolną liczbę i jest tym samym układem, co ekran „Dostępność"
     w Calamari.

     Nazw typów NIE przerabiamy: wpisuje je administrator i w jednej firmie
     bywają po polsku i po angielsku naraz („Urlop bezpłatny" obok
     „Sick Leave"). Każda automatyczna zmiana wielkości liter coś psuje. */
  const ent = a.entitlement || [];
  /* Dwa układy, bo jeden nie obsługuje obu skrajności.
     Do czterech typów: kafelki 2×2 z dużą liczbą — tak wygląda to w makiecie
     i tak będzie u większości firm, które mają urlop, żądanie i zdalną.
     Powyżej czterech: wiersz na typ. Kafelki zjadłyby pół panelu, a konto
     testowe pokazuje, że siedem typów to realna możliwość. */
  $('lim').classList.toggle('is-tiles', ent.length > 0 && ent.length <= 4);
  $('lim').classList.toggle('is-rows', ent.length > 4);
  $('lim').innerHTML = ent.length
    ? ent.map(e => {
        // Jednostka osobnym elementem: w kafelku liczba ma być duża,
        // a „dni" przy niej drobne. Jedną wielkością „18 dni" gubi efekt.
        const ile = e.unlimited
          ? '∞'
          // spacja w TREŚCI, nie tylko margines w CSS — bez niej czytnik
          // ekranu dostaje „12dni" i czyta to jako jeden wyraz
          : `${fmtNumber(e.remaining)} <i class="limunit">${esc(fmtUnit(e.remaining, e.hours))}</i>`;
        return `<div class="limrow" role="listitem">
          <span class="limname">${esc(e.absenceTypeName)}</span>
          <b class="limval">${ile}</b>
        </div>`;
      }).join('')
    : `<p class="more" style="padding-left:0" role="listitem">${esc(t('noLimits'))}</p>`;

  const mine = a.mine || [];
  $('mineEye').classList.toggle('hidden', !mine.length);
  // Liczby dni nie pokazujemy: wymiar liczy Calamari (święta, części dnia),
  // a zgadywanie z zakresu dat dałoby liczbę rozjeżdżającą się z aplikacją.
  $('mine').innerHTML = mine.map(m => `
    <div class="up${m.pending ? ' pend' : ''}" role="listitem">
      <span class="pipe" aria-hidden="true"></span><div>
      <span class="d">${esc(fmtRange(m.from, m.to))}</span>
      <div class="t">${esc(m.typeName)}${m.pending
        ? ` · <span class="pendmark">${esc(t('pendingShort'))}</span>` : ''}</div>
    </div></div>`).join('');

  /* Kto dziś nieobecny. Sekcja znika tylko wtedy, gdy kalendarza w ogóle nie
     ma (brak uprawnień albo błąd) — „dziś nikogo nie brakuje" to też odpowiedź
     i jest użyteczna. Źródło: searchAbsenceRequestsForCalendar.do. */
  const tod = a.today;
  const brakKalendarza = a.calendar === null;
  $('s-who').classList.toggle('hidden', !tod && !brakKalendarza);
  if (brakKalendarza) {
    $('whoCount').textContent = '';
    $('who').innerHTML = `<p class="more" style="padding-left:0">${esc(t('calendarOff'))}</p>`;
  } else if (tod) {
    const off = tod.timeoff || [], work = tod.work || [];
    const razem = off.length + work.length;
    // Licznik przy nagłówku sekcji zamiast drugiego nagłówka w środku —
    // „Dzisiaj nieobecni" i „Nieobecni · 3" jedno pod drugim to powtórzenie.
    $('whoCount').textContent = razem ? `· ${razem}` : '';
    $('who').innerHTML = razem
      ? (off.length ? catHead(t('catTimeoff'), 'is-off') + facepile(off) : '') +
        (work.length ? catHead(t('catWork'), 'is-work') + facepile(work) : '')
      : `<p class="more" style="padding-left:0">${esc(t('nobodyOut'))}</p>`;
  }
}

/* Rząd awatarów, jak „kto dziś nieobecny" na Slacku.
   Przy pięciu osobach lista imion i typów zabierała pół panelu — twarze
   skanuje się wzrokiem od razu, a szczegóły są w dymku pod kursorem.

   Dymek NIE jest atrybutem `title`: ten pojawia się po sekundzie, nie da się
   go wywołać z klawiatury i czytniki ekranu traktują go różnie. Zamiast tego
   `aria-label` z kompletem informacji plus własny dymek na :hover i :focus.
   Każdy awatar jest tabulowalny, więc ta sama treść jest dostępna bez myszy. */
function facepile(list) {
  if (!list || !list.length) return '';
  const shown = list.slice(0, 8), rest = list.length - shown.length;
  const rows = shown.map(p => {
    const okres = fmtRange(p.start, p.end);
    const opis = [p.typeName, okres].filter(Boolean).join(' · ') +
                 (p.pending ? ` · ${t('pendingLong')}` : '');
    return `<span class="face${p.pending ? ' pend' : ''}" role="listitem" tabindex="0"
      aria-label="${esc(p.name + (opis ? ', ' + opis : ''))}">` +
      (p.avatar
        // alt pusty: nazwisko niesie już aria-label rodzica, inaczej czytnik
        // przeczyta je dwa razy
        ? `<img src="${esc(p.avatar)}" alt="" loading="lazy">`
        : `<span class="ini" style="background:${color(p.name)}">${esc(p.initials)}</span>`) +
      `<span class="tip" aria-hidden="true"><b>${esc(p.name)}</b>` +
        (p.typeName ? `<span>${esc(p.typeName)}</span>` : '') +
        (okres ? `<span>${esc(okres)}</span>` : '') +
        (p.pending ? `<span class="tip-pend">${esc(t('pendingLong'))}</span>` : '') +
      `</span></span>`;
  }).join('');
  return `<div class="faces" role="list">${rows}` +
    (rest > 0 ? `<span class="face more-face" role="listitem">+${rest}</span>` : '') + '</div>';
}

// Nagłówek grupy: pasek w kolorze kategorii i nazwa. Bez licznika — liczba
// twarzy jest widoczna wprost, a łączna suma stoi przy nagłówku sekcji.
function catHead(label, kind) {
  return `<p class="cat ${kind}">${esc(label)}</p>`;
}


/* ------------------------------------------------------- wybór projektu */

let ddOpen = false;
let stagedProject = null;   // wybór przed startem pracy; po starcie przypisujemy go serwerowi

function projectList(s) { return (s.screen && s.screen.activeProjects) || []; }

function currentProjectId(s) {
  if (s.state === 'STOPPED') return stagedProject;
  return s.project && s.project.id != null ? s.project.id : null;
}

function renderProjects(s) {
  const list = projectList(s);
  const sel = currentProjectId(s);
  const chosen = list.find(p => String(p.id) === String(sel));

  $('ddDot').style.background = chosen ? chosen.color : 'var(--n300)';
  $('ddLabel').textContent = chosen ? chosen.name : t('noProject');
  $('ddBtn').disabled = actionPending || s.state === 'UNKNOWN';

  // tabindex=-1 na pozycjach: po liście chodzi się strzałkami, nie Tabem
  // (wzorzec listbox z WAI-ARIA APG), a Tab wychodzi z całej listy.
  const row = (id, name, color) => {
    const on = String(id) === String(sel == null ? '' : sel);
    return `<button type="button" class="dd-item" role="option" tabindex="-1"
      aria-selected="${on}" data-id="${esc(id)}">
      <span class="dd-dot" aria-hidden="true" style="background:${color ? esc(color) : 'var(--n300)'}"></span>
      <span class="dd-name">${esc(name)}</span></button>`;
  };
  /* Nie przepisujemy listy, gdy jest otwarta. Odpytanie leci co 2 s, a każde
     przepisanie innerHTML usuwa z DOM element pod fokusem — użytkownik, który
     wybiera projekt strzałkami, traci miejsce w połowie wyboru i fokus ląduje
     na <body>. Po zamknięciu lista i tak odmaluje się z aktualnych danych. */
  if (!ddOpen) {
    $('ddList').innerHTML =
      row('', t('noProject'), null) + '<div class="dd-sep"></div>' +
      list.map(p => row(p.id, p.name, p.color)).join('');
  }

  const note = $('ddNote');
  if (s.state === 'STOPPED') {
    note.classList.remove('hidden', 'err');
    note.textContent = stagedProject
      ? t('projectAfterStart') : t('projectAnytime');
  } else if (!projectError) {
    note.classList.add('hidden');
  }
}

let projectError = null;

/* Lista projektów to własny listbox, więc całą obsługę klawiatury trzeba
   napisać ręcznie — natywny <select> dostałby ją od przeglądarki.
   Wzorzec: WAI-ARIA APG „Listbox". Strzałki chodzą po pozycjach, Enter
   i spacja wybierają, Escape zamyka i oddaje fokus przyciskowi, Tab wychodzi. */

function ddItems() { return Array.from($('ddList').querySelectorAll('.dd-item')); }

function ddFocus(i) {
  const items = ddItems();
  if (!items.length) return;
  const n = Math.max(0, Math.min(items.length - 1, i));
  items.forEach(el => el.classList.remove('cursor'));
  items[n].classList.add('cursor');
  items[n].focus();
}

function closeDd(returnFocus) {
  if (!ddOpen) return;
  ddOpen = false;
  $('dd').classList.remove('open');
  $('ddList').classList.add('hidden');
  $('ddBtn').setAttribute('aria-expanded', 'false');
  // Bez tego fokus zostaje na zniknięciem elemencie i ląduje na <body> —
  // użytkownik klawiatury traci miejsce w panelu.
  if (returnFocus) $('ddBtn').focus();
}

function openDd() {
  if (ddOpen || $('ddBtn').disabled) return;
  ddOpen = true;
  $('dd').classList.add('open');
  $('ddList').classList.remove('hidden');
  $('ddBtn').setAttribute('aria-expanded', 'true');
  const items = ddItems();
  const at = items.findIndex(el => el.getAttribute('aria-selected') === 'true');
  ddFocus(at < 0 ? 0 : at);
}

$('ddBtn').onclick = () => { ddOpen ? closeDd(true) : openDd(); };

$('ddBtn').addEventListener('keydown', e => {
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Enter' || e.key === ' ') {
    e.preventDefault();
    openDd();
  }
});

$('ddList').addEventListener('keydown', e => {
  const items = ddItems();
  const at = items.indexOf(document.activeElement);
  switch (e.key) {
    case 'ArrowDown': e.preventDefault(); ddFocus(at + 1); break;
    case 'ArrowUp':   e.preventDefault(); ddFocus(at - 1); break;
    case 'Home':      e.preventDefault(); ddFocus(0); break;
    case 'End':       e.preventDefault(); ddFocus(items.length - 1); break;
    case 'Escape':    e.preventDefault(); closeDd(true); break;
    case 'Tab':       closeDd(false); break;
    case 'Enter':
    case ' ':         e.preventDefault(); document.activeElement.click(); break;
  }
});

$('ddList').addEventListener('click', async e => {
  const item = e.target.closest('.dd-item');
  if (!item || !snap) return;
  const raw = item.dataset.id;
  const id = raw === '' ? null : Number(raw);
  closeDd(true);

  if (snap.state === 'STOPPED') {
    // nie ma czego przełączać na serwerze — zapamiętujemy do czasu startu
    stagedProject = id;
    renderProjects(snap);
    return;
  }

  const note = $('ddNote');
  note.classList.remove('hidden', 'err');
  note.textContent = t('projectAssigning');
  const r = await send({ type: 'setProject', projectId: id });
  if (r && r.ok === false) {
    projectError = true;
    note.classList.add('err');
    note.textContent = t('projectFailed') + ' ' + (r.reason || '');
  } else {
    projectError = null;
    note.classList.add('hidden');
  }
  refresh();
});

document.addEventListener('click', e => {
  if (ddOpen && !e.target.closest('#dd')) closeDd(false);
});
/* Escape ma zamykać to, co jest najbardziej „na wierzchu": najpierw listę
   projektów, potem podpowiedzi zastępcy, potem formularz, a na końcu — gdy
   panel wisi nad stroną — cały panel. Bez ostatniego kroku użytkownik
   klawiatury nie ma jak zamknąć pływającego okna. */
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (ddOpen) { closeDd(true); return; }
  if (subItems().length) { closeSubList(); return; }
  if (!$('reqForm').classList.contains('hidden')) { closeReqForm(true); return; }
  if (host === 'pill') {
    try { parent.postMessage({ calamari: 'closePanel' }, '*'); } catch (err) {}
  }
});

/* ------------------------------------------------- oś czasu dnia pracy */

/* Przesunięcie strefy pracownika względem UTC. Potrzebne, bo znaczniki zmian
   przychodzą jako czas absolutny, a plan dnia („08:00–16:00") jest czasem
   ściennym pracownika. Bez tego oś rozjechałaby się każdemu poza Warszawą. */
function tzOffsetMs(nowMs, timeZone) {
  try {
    const f = new Intl.DateTimeFormat('en-US', { timeZone, hour12: false,
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const q = {};
    for (const part of f.formatToParts(new Date(nowMs))) if (part.type !== 'literal') q[part.type] = part.value;
    const asUTC = Date.UTC(+q.year, +q.month - 1, +q.day, +q.hour % 24, +q.minute, +q.second);
    return asUTC - nowMs;
  } catch (e) {
    return -new Date(nowMs).getTimezoneOffset() * 60000;
  }
}

let tl = null;   // { lo, span, off, openFrom, openBreakFrom, nowAtRender }

function wallHm(absMs, off) {
  const d = new Date(absMs + off);
  return String(d.getUTCHours()).padStart(2, '0') + ':' + String(d.getUTCMinutes()).padStart(2, '0');
}

function renderTimeline(s) {
  const el = $('track');
  const sc = s.screen;
  const nowMs = Date.parse(sc && sc.now);
  if (!el || !sc || !Number.isFinite(nowMs)) { if (el) el.innerHTML = ''; tl = null; return; }

  const off = tzOffsetMs(nowMs, sc.timezone);
  const w = new Date(nowMs + off);
  const dayStartWall = Date.UTC(w.getUTCFullYear(), w.getUTCMonth(), w.getUTCDate());
  const planAt = hhmm => {
    const m = /^(\d{1,2}):(\d{2})/.exec(String(hhmm || ''));
    return m ? dayStartWall + (+m[1]) * 3600000 + (+m[2]) * 60000 - off : null;
  };

  const d = sc.dayOfWorkingWeek || {};
  const planA = d.workingDay ? planAt(d.start) : null;
  const planB = d.workingDay ? planAt(d.end) : null;

  const shifts = (sc.dayShifts || []).map(x => ({
    a: Date.parse(x.startedTime),
    b: x.finishedTime ? Date.parse(x.finishedTime) : (x.stoppedTime ? Date.parse(x.stoppedTime) : null),
    breaks: (x.breaks || []).map(br => ({
      a: Date.parse(br.breakStarted),
      b: br.breakFinished ? Date.parse(br.breakFinished) : null
    })).filter(br => Number.isFinite(br.a))
  })).filter(x => Number.isFinite(x.a));

  let lo = nowMs, hi = nowMs;
  const take = v => { if (Number.isFinite(v)) { lo = Math.min(lo, v); hi = Math.max(hi, v); } };
  take(planA); take(planB);
  for (const sh of shifts) { take(sh.a); take(sh.b == null ? nowMs : sh.b); }
  if (!(hi > lo)) { el.innerHTML = ''; tl = null; return; }

  const span = hi - lo;
  const pct = t => Math.max(0, Math.min(100, (t - lo) / span * 100));
  const out = [];
  let openFrom = null, openBreakFrom = null;

  if (planA != null && planB != null) {
    out.push(`<i class="planwin" style="left:${pct(planA)}%;width:${pct(planB) - pct(planA)}%"></i>`);
  }
  for (const sh of shifts) {
    const end = sh.b == null ? nowMs : sh.b;
    if (sh.b == null) openFrom = sh.a;
    out.push(`<i class="seg${sh.b == null ? ' open' : ''}" style="left:${pct(sh.a)}%;width:${Math.max(0.5, pct(end) - pct(sh.a))}%"></i>`);
    for (const br of sh.breaks) {
      const be = br.b == null ? nowMs : br.b;
      if (br.b == null) openBreakFrom = br.a;
      out.push(`<i class="brk${br.b == null ? ' open' : ''}" style="left:${pct(br.a)}%;width:${Math.max(0.8, pct(be) - pct(br.a))}%"></i>`);
    }
  }
  out.push(`<i class="now" style="left:${pct(nowMs)}%"></i>`);
  el.innerHTML = out.join('');

  $('trkA').textContent = wallHm(lo, off);
  $('trkB').textContent = wallHm(hi, off);

  /* Oś to czysta grafika — bez opisu czytnik ekranu mija ją w milczeniu.
     Opis wymienia to samo, co widać: okno planu, każdą zmianę z przerwami. */
  const desc = [`${t('a11yTimeline')}: ${wallHm(lo, off)}–${wallHm(hi, off)}`];
  if (planA != null && planB != null) {
    desc.push(`${t('a11yPlanWindow')} ${wallHm(planA, off)}–${wallHm(planB, off)}`);
  }
  shifts.forEach((sh, i) => {
    const end = sh.b == null ? null : sh.b;
    desc.push(`${i + 1}. ${t.plural(1, 'shift')} ` +
      `${wallHm(sh.a, off)}–${end == null ? t('a11yNow') : wallHm(end, off)}` +
      (sh.breaks.length ? `, ${t('a11yBreaks')}: ` +
        sh.breaks.map(br => `${wallHm(br.a, off)}–${br.b == null ? t('a11yNow') : wallHm(br.b, off)}`).join(', ') : ''));
  });
  el.setAttribute('aria-label', desc.join('. ') + '.');

  tl = { lo, span, off, openFrom, openBreakFrom, nowAtRender: nowMs };
}

function tickTimeline() {
  if (!tl || !snap) return;
  const el = $('track');
  if (!el) return;
  const now = tl.nowAtRender + Math.max(0, Date.now() - snap._renderedAt);
  const pct = t => Math.max(0, Math.min(100, (t - tl.lo) / tl.span * 100));
  const seg = el.querySelector('.seg.open');
  if (seg && tl.openFrom != null) seg.style.width = Math.max(0.5, pct(now) - pct(tl.openFrom)) + '%';
  const brk = el.querySelector('.brk.open');
  if (brk && tl.openBreakFrom != null) brk.style.width = Math.max(0.8, pct(now) - pct(tl.openBreakFrom)) + '%';
  const nowEl = el.querySelector('.now');
  if (nowEl) nowEl.style.left = pct(now) + '%';
}

/* Trzy liczby pod osią — te same, które pokazuje zakładka Zegar:
   przepracowane, przerwy, pozostało do planu.
   Uwaga: to są sumy CAŁEGO DNIA, nie bieżącej zmiany. Duży licznik wyżej
   pokazuje bieżącą zmianę — stąd dwie różne liczby i obie są poprawne. */
function renderSummary(s, driftSec) {
  const box = $('trkSum');
  const sc = s.screen;
  if (!box || !sc || s.dayWorkSeconds == null) { if (box) box.textContent = ''; return; }
  const drift = driftSec || 0;
  // Sumy liczy service worker; tutaj tylko dokładamy sekundy, które upłynęły
  // od pobrania stanu — praca rośnie poza przerwą niepłatną, przerwa w jej trakcie.
  const work = s.dayWorkSeconds + (s.state === 'BREAK' && !sc._breakPaid ? 0 : drift);
  const brk = s.dayBreakSeconds + (s.state === 'BREAK' ? drift : 0);
  const planSec = (sc.dayOfWorkingWeek || {}).seconds || 0;
  const left = Math.max(0, planSec - work);

  /* Kolorowa kropka + liczba. Czytnik ekranu nie widzi koloru, a atrybut
     title bywa pomijany — stąd nazwa wprost w treści, ukryta wzrokowo. */
  const cell = (cls, mark, label, val) =>
    `<span class="${cls}"><em aria-hidden="true">${mark}</em>` +
    `<span class="sr">${esc(label)}: ${esc(t.dur(val))}</span>` +
    `<span class="num" aria-hidden="true">${fmtHms(val)}</span></span>`;
  box.innerHTML =
    cell('t-work', '', t('worked'), work) +
    cell('t-break', '', t('breaks'), brk) +
    (planSec ? cell('t-left', '↑', t('left'), left) : '');
}

/* ------------------------------------------------------------- pomocnicze */

const PALETTE = ['#7f93a9', '#21876e', '#0d1d44', '#5a6e84', '#27a082'];
function color(i) { let h = 0; for (const c of String(i)) h = (h * 31 + c.charCodeAt(0)) % 997; return PALETTE[h % PALETTE.length]; }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
/* Saldo i jego jednostka. Rozbite na dwie funkcje, bo w kafelku liczba
   i jednostka mają różną wielkość.

   Saldo bywa ułamkowe (pół dnia, 7,5 godziny), a polskie reguły mnogości
   dotyczą tylko liczb całkowitych — dla ułamka bierzemy formę dopełniaczową
   („1,5 dnia" brzmi źle, „1,5 dni" jest tym, czego ludzie używają).
   Jednostkę mówi serwer, nie zgadujemy jej. */
function fmtNumber(value) {
  return new Intl.NumberFormat(t.lang, { maximumFractionDigits: 1 }).format(Number(value) || 0);
}
function fmtUnit(value, hours) {
  const n = Number(value) || 0;
  const key = hours ? 'hour' : 'day';
  return t.plural(Number.isInteger(n) ? n : 5, key);
}

/* Okres nieobecności słowami. Miesiące bierzemy z Intl, nie z własnej tablicy:
   stara tablica była polska na sztywno, więc po przełączeniu konta na angielski
   daty i tak czytało się „2–6 listopada". */
/* „2026-11-02" parsuje się jako PÓŁNOC UTC. Odczytane potem lokalnie daje
   w Polsce ten sam dzień (UTC+1/+2), ale na zachód od UTC — dzień wcześniej.
   Calamari ma klientów w USA i Hiszpanii, więc daty rozjeżdżały się im
   o jeden dzień, a liczenie dni roboczych łapało zły weekend. */
function parseDay(iso) {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  return m ? new Date(+m[1], +m[2] - 1, +m[3]) : new Date(NaN);
}

function fmtRange(from, to) {
  const a = parseDay(from), b = parseDay(to);
  if (isNaN(a) || isNaN(b)) return '';
  const dzien = d => new Intl.DateTimeFormat(t.lang, { day: 'numeric', month: 'long' }).format(d);
  if (a.getTime() === b.getTime()) return dzien(a);
  if (a.getMonth() === b.getMonth() && a.getFullYear() === b.getFullYear()) {
    // „2–6 listopada" po polsku, „November 2–6" po angielsku
    const pelna = dzien(b), sam = new Intl.DateTimeFormat(t.lang, { day: 'numeric' }).format(a);
    return t.lang === 'pl' ? `${sam}–${pelna}` : `${pelna.replace(/\d+$/, `${sam}–$&`)}`;
  }
  return `${dzien(a)} – ${dzien(b)}`;
}

function startTicker() {
  if (ticker) clearInterval(ticker);
  if (!snap || !snap.settings.modTime || !['WORKING', 'BREAK'].includes(snap.state)) { paintClock(); return; }
  ticker = setInterval(paintClock, 1000);
}

/* ------------------------------------------------------------------ akcje */

function refresh(force = false) {
  if (refreshing) return refreshing;
  refreshing = refreshOnce(force).finally(() => { refreshing = null; });
  return refreshing;
}
async function refreshOnce(force = false) {
  const s = await send({ type: 'get', force });
  if (dead) return;
  if (!s || s.ok === false || !s.settings) {
    snap = null;
    if (ticker) clearInterval(ticker);
    $('big').textContent = '—';
    $('bigSub').textContent = 'Brak aktualnych danych';
    for (const id of ['actsStopped', 'actsWorking', 'actsBreak', 'projWrap', 'breakChoice', 'noBreaks']) $(id).classList.add('hidden');
    // service worker odpowiedział błędem — pokaż go zamiast pustego panelu
    const el = $('conn');
    el.classList.remove('hidden');
    $('connKind').textContent = 'Rozszerzenie zgłosiło błąd';
    $('connDetail').textContent = String(s?.error || 'Brak odpowiedzi z rozszerzenia');
    return;
  }
  s._renderedAt = s.sampledAt || Date.now();
  render(s);
}

const ACTION_FAIL = {
  BRAK_NAJEMCY:     'Nie wiadomo, na którym koncie Calamari działać.',
  BRAK_SESJI:       'Nie jesteś zalogowany w Calamari w tej przeglądarce.',
  SESJA_WYGASLA:    'Sesja Calamari wygasła. Zaloguj się ponownie.',
  ZABLOKOWANE:      'Żądanie w ogóle nie dotarło — CORS albo WAF.',
  ODRZUCONY_ORIGIN: 'Backend odrzucił żądanie z rozszerzenia (403).',
  ZABRONIONE:       'Backend odmówił (403) — token CSRF albo uprawnienia.',
  BRAK_KARTY:       'Otwórz gdziekolwiek kartę Calamari — przez nią idą żądania.',
  KARTA_USPIONA:    'Chrome uśpił kartę Calamari. Rozszerzenie próbowało ją obudzić — kliknij ją raz i ponów.',
  KARTA_ODMOWILA:   'Nie udało się wykonać żądania w karcie Calamari.',
  BLAD_HTTP:        'Calamari zwróciło błąd.'
};

let lastError = null;

function actionFailed(r) {
  if (r?.ok === true) { lastError = null; return false; }
  r ||= { kind: 'BRAK_ODPOWIEDZI', reason: 'Brak potwierdzenia z rozszerzenia.' };
  const breakError = { BRAK_PRZERW: 'noBreaks', WYBIERZ_PRZERWE: 'chooseBreak', PRZERWA_NIEDOSTEPNA: 'breakUnavailable', PRZERWA_STAN: 'breakOnlyWorking' }[r.kind];
  lastError =
    (breakError ? '<b>' + esc(t(breakError)) + '</b>' :
    '<b>' + esc(ACTION_FAIL[r.kind] || 'Akcja nie przeszła.') + '</b><br>' +
    'Nie otrzymano potwierdzenia. Sprawdź stan w Calamari przed ponowieniem akcji.' +
    (r.reason ? '<br><span style="opacity:.8;word-break:break-word">' + esc(r.reason) + '</span>' : '')) +
    '<br><a href="#" id="errClose" style="color:inherit;text-decoration:underline">zamknij</a>';
  const el = $('blocked');
  el.classList.remove('hidden');
  el.innerHTML = lastError;
  return true;
}

// delegacja, bo treść błędu jest przerysowywana
document.addEventListener('click', e => {
  if (e.target && e.target.id === 'errClose') {
    e.preventDefault();
    lastError = null;
    $('blocked').classList.add('hidden');
  }
});

let actionPending = false;
async function act(type, extra) {
  if (actionPending) return;
  actionPending = true;
  if (snap) renderTime(snap);
  try {
    const result = await send({ type, ...(extra || {}) });
    actionFailed(result);
    if (result?.snap) render(result.snap);
  } finally {
    actionPending = false;
    if (snap) renderTime(snap);
  }
}

$('bStart').onclick = async () => {
  const wanted = stagedProject;
  await act('clockIn');
  // clock-in nie przyjmuje projektu — przypisujemy go osobnym żądaniem zaraz po starcie
  if (wanted != null && !lastError) {
    const r = await send({ type: 'setProject', projectId: wanted });
    if (r && r.ok === false) {
      const note = $('ddNote');
      note.classList.remove('hidden'); note.classList.add('err');
      note.textContent = 'Praca ruszyła, ale projektu nie udało się przypisać. ' + (r.reason || '');
    } else {
      stagedProject = null;
    }
    refresh();
  }
};
$('bStop').onclick = $('bStop2').onclick = () => act('clockOut');
$('breakType').onchange = () => { if (snap) renderTime(snap); };
$('bBreak').onclick    = () => act('breakStart', { breakType: $('breakType').value });
$('bBreakEnd').onclick = () => act('breakStop');

/* ----------------------------------------------------- formularz wniosku

   Zestaw pól NIE jest zaszyty w kodzie. Serwer zwraca per typ absencji flagi
   reason/substitute/comment/attachment o wartościach DISABLED | OPTIONAL |
   REQUIRED oraz allowHoursRequesting. Formularz renderuje się z tych flag,
   bo zależą od typu i od ustawień organizacji. Szczegóły: 06_api-research.md §7. */

// Adresy sprawdzone 26.10.2026 w aplikacji: „Wnioskuj" w menu Nieobecności
// prowadzi na /absence/request i to tam jest pole „Załącznik".
const CLOCK_URL = 'https://app-new.calamari.io/clockin/clock';
const REQUEST_URL = 'https://app-new.calamari.io/absence/request';

let reqTypes = null;              // definicje typów z serwera
let reqState = null;              // bieżący stan formularza
let subTimer = null;

const PART_PL = { MORNING: 'Rano', AFTERNOON: 'Po południu', MIDDAY: 'W południe',
                  END_OF_DAY: 'Koniec dnia', BEGIN_OF_DAY: 'Początek dnia' };
const partLabel = v => PART_PL[v] || String(v || '').toLowerCase().replace(/_/g, ' ');
// localISODate z api.js, nie toISOString(): to drugie zwraca dobę UTC, więc
// po polskiej północy formularz podstawiał wczorajszą datę.
const todayISO = () => localISODate();

function reqMsg(kind, html) {
  const el = $('reqMsg');
  el.className = 'reqmsg ' + kind;
  el.classList.toggle('hidden', !html);
  el.innerHTML = html || '';
}

function currentType() {
  return (reqTypes || []).find(t => String(t.id) === String(reqState && reqState.absenceTypeId)) || null;
}

function renderFields() {
  const box = $('reqFields');
  const at = currentType();
  const st = reqState;
  const opt = (v, label, sel) => `<option value="${esc(v)}"${String(sel) === String(v) ? ' selected' : ''}>${esc(label)}</option>`;
  const out = [];

  // Gwiazdka przy etykiecie to sam kolor i znak — czytnik ekranu musi dostać
  // słowo „pole wymagane" oraz aria-required na samym polu (SC 1.3.1, 3.3.2).
  const star = req => req
    ? `<span class="req" aria-hidden="true">*</span><span class="sr"> ${esc(t('a11yRequired'))}</span>` : '';
  const ar = req => req ? ' aria-required="true"' : '';

  out.push(`<div class="fld"><label for="rqType">${esc(t('kind'))}</label>
    <select id="rqType">${(reqTypes || []).map(x => opt(x.id, x.name, st.absenceTypeId)).join('')}</select></div>`);

  /* Typ z obowiązkowym załącznikiem. Widżet nie umie wysyłać plików, więc
     zamiast dać wypełnić formularz i dopiero potem oberwać odmową z serwera
     (albo, gorzej, założyć wniosek bez wymaganego dokumentu), mówimy to od
     razu i odsyłamy na stronę. Reszta pól jest ukryta — wypełnianie ich
     tutaj nie miałoby po co. */
  if (at && at.attachment === 'REQUIRED') {
    out.push(`<div class="attwarn" role="status">
      <b>${esc(t('needsAttachment'))}</b>
      <span>${esc(t('attachmentWhy'))}</span>
      <button type="button" class="b" id="rqOpenApp">${esc(t('openRequest'))}</button>
    </div>`);
    box.innerHTML = out.join('');
    wireFields();
    reqMsg('', '');
    $('fDays').classList.add('hidden');
    $('fSend').classList.add('hidden');
    $('fSend').disabled = true;
    return;
  }
  $('fSend').classList.remove('hidden');

  // Daty; części dnia tylko gdy serwer je dopuszcza dla tego typu
  const parts = st.part || { can: false, from: [], to: [] };
  out.push(`<div class="fld"><label for="rqFrom">${esc(t('from'))}</label><div class="pair">
      <input type="date" id="rqFrom" value="${esc(st.absenceStart || '')}">
      ${parts.can ? `<select id="rqFromPart" aria-label="${esc(t('from'))} — ${esc(t('a11yDaysOf'))}">${parts.from.map(v => opt(v, partLabel(v), st.fromPart)).join('')}</select>` : ''}
    </div></div>`);
  out.push(`<div class="fld"><label for="rqTo">${esc(t('to'))}</label><div class="pair">
      <input type="date" id="rqTo" value="${esc(st.absenceEnd || '')}">
      ${parts.can ? `<select id="rqToPart" aria-label="${esc(t('to'))} — ${esc(t('a11yDaysOf'))}">${parts.to.map(v => opt(v, partLabel(v), st.toPart)).join('')}</select>` : ''}
    </div></div>`);

  if (at && at.reason !== 'DISABLED') {
    const req = at.reason === 'REQUIRED';
    out.push(`<div class="fld"><label for="rqReason">${esc(t('reason'))}${star(req)}</label>` +
      (at.predefinedReasons.length
        ? `<select id="rqReason"${ar(req)}>${(req ? '' : opt('', '—', st.reason))}${at.predefinedReasons.map(r => opt(r, r, st.reason)).join('')}</select>`
        : `<input type="text" id="rqReason"${ar(req)} value="${esc(st.reason || '')}">`) + '</div>');
  }

  if (at && at.substitute !== 'DISABLED') {
    const req = at.substitute === 'REQUIRED';
    // Pole z podpowiedziami = combobox. Bez role/aria-expanded/aria-activedescendant
    // czytnik ekranu nie wie, że pod spodem pojawiła się lista wyników.
    out.push(`<div class="fld sub-pick"><label for="rqSub">${esc(t('substitute'))}${star(req)}</label>` +
      (st.substituteName
        ? `<div class="sub-chosen"><span>${esc(st.substituteName)}</span>
           <button type="button" id="rqSubClear"
             aria-label="${esc(t('subChange'))}: ${esc(st.substituteName)}">${esc(t('subChange'))}</button></div>`
        : `<input type="text" id="rqSub" placeholder="${esc(t('subSearch'))}" autocomplete="off"
             role="combobox" aria-expanded="false" aria-controls="rqSubList"
             aria-autocomplete="list" aria-haspopup="listbox"${ar(req)}>
           <div class="sub-list hidden" id="rqSubList" role="listbox"
                aria-label="${esc(t('a11ySubstituteList'))}"></div>`) + '</div>');
  }

  if (at && at.comment !== 'DISABLED') {
    const req = at.comment === 'REQUIRED';
    out.push(`<div class="fld"><label for="rqComment">${esc(t('comment'))}${star(req)}</label>
      <textarea id="rqComment" rows="2"${ar(req)} placeholder="${req ? '' : esc(t('commentOptional'))}">${esc(st.comment || '')}</textarea></div>`);
  }

  /* Załączników celowo nie ma w formularzu — nawet jako informacji.
     Pusty blok „załączniki dodasz w Calamari" niczego nie dawał: brak pola
     sam w sobie mówi, że nie da się nic dodać, a komunikat tylko zabierał
     miejsce i przypominał o niedokończonej funkcji przy każdym wniosku.
     Flaga `attachmentRequirement` z serwera dalej jest w danych typu —
     wróci tu, gdy rozpoznamy format `attachments[]` (06_api-research.md §7). */

  box.innerHTML = out.join('');
  wireFields();
  renderRestrictions();
  updateDays();
}

function wireFields() {
  const on = (id, ev, fn) => { const e = $(id); if (e) e.addEventListener(ev, fn); };
  // Strona wniosku w Calamari — ta sama, w której jest pole „Załącznik".
  on('rqOpenApp', 'click', () => chrome.tabs.create({ url: REQUEST_URL }));
  on('rqType', 'change', async e => {
    reqState.absenceTypeId = e.target.value;
    reqState.substitute = null; reqState.substituteName = null; reqState.reason = '';
    await refreshParts();
    renderFields();
  });
  on('rqFrom', 'change', async e => {
    reqState.absenceStart = e.target.value;
    if (!reqState.absenceEnd || reqState.absenceEnd < e.target.value) reqState.absenceEnd = e.target.value;
    await refreshParts(); renderFields();
  });
  on('rqTo', 'change', async e => { reqState.absenceEnd = e.target.value; await refreshParts(); renderFields(); });
  on('rqFromPart', 'change', e => { reqState.fromPart = e.target.value; updateDays(); });
  on('rqToPart', 'change', e => { reqState.toPart = e.target.value; updateDays(); });
  on('rqReason', 'input', e => { reqState.reason = e.target.value; });
  on('rqReason', 'change', e => { reqState.reason = e.target.value; });
  on('rqComment', 'input', e => { reqState.comment = e.target.value; });
  on('rqSubClear', 'click', () => { reqState.substitute = null; reqState.substituteName = null; renderFields(); });
  on('rqSub', 'input', e => {
    clearTimeout(subTimer);
    const q = e.target.value;
    subTimer = setTimeout(() => searchSubstitutes(q), 250);
  });
  // Strzałkami po podpowiedziach bez opuszczania pola tekstowego
  on('rqSub', 'keydown', e => {
    const items = subItems();
    const at = items.findIndex(el => el.classList.contains('cursor'));
    switch (e.key) {
      case 'ArrowDown': if (items.length) { e.preventDefault(); subCursor(at + 1); } break;
      case 'ArrowUp':   if (items.length) { e.preventDefault(); subCursor(at - 1); } break;
      case 'Enter':     if (at >= 0) { e.preventDefault(); pickSubstitute(items[at]); } break;
      case 'Escape':    if (items.length) { e.preventDefault(); e.stopPropagation(); closeSubList(); } break;
    }
  });
}

async function searchSubstitutes(query) {
  const list = $('rqSubList');
  const input = $('rqSub');
  if (!list) return;
  const people = await send({ type: 'employees', query });
  if (!Array.isArray(people) || !people.length) {
    list.classList.remove('hidden');
    // role=listbox nie może zawierać zwykłego tekstu — pusty wynik mówi status
    list.innerHTML = `<div class="more" style="padding:6px 8px" role="option"
      aria-disabled="true" aria-selected="false">${esc(t('noResults'))}</div>`;
    if (input) input.setAttribute('aria-expanded', 'true');
    return;
  }
  list.classList.remove('hidden');
  list.innerHTML = people.map((p, i) => `
    <button type="button" class="sub-item" role="option" tabindex="-1" aria-selected="false"
            id="sub-opt-${i}" data-id="${esc(p.id)}" data-name="${esc(p.name)}">
      ${p.avatar ? `<img src="${esc(p.avatar)}" alt="">` : '<span class="ph" aria-hidden="true"></span>'}
      <b>${esc(p.name)}</b>${p.position ? `<span>${esc(p.position)}</span>` : ''}
    </button>`).join('');
  if (input) input.setAttribute('aria-expanded', 'true');
  list.querySelectorAll('.sub-item').forEach(b => b.addEventListener('click', () => pickSubstitute(b)));
}

function pickSubstitute(b) {
  reqState.substitute = b.dataset.id;
  reqState.substituteName = b.dataset.name;
  renderFields();
  // Po wyborze pole znika i zastępuje je „wybrany zastępca" — fokus musi
  // za tym pójść, inaczej ląduje na <body> i użytkownik gubi formularz.
  const back = $('rqSubClear');
  if (back) back.focus();
}

function subItems() {
  const list = $('rqSubList');
  return list ? Array.from(list.querySelectorAll('.sub-item')) : [];
}

function subCursor(i) {
  const items = subItems();
  if (!items.length) return;
  const n = (i + items.length) % items.length;
  items.forEach(el => { el.classList.remove('cursor'); el.setAttribute('aria-selected', 'false'); });
  items[n].classList.add('cursor');
  items[n].setAttribute('aria-selected', 'true');
  items[n].scrollIntoView({ block: 'nearest' });
  // aria-activedescendant zamiast przenoszenia fokusu: użytkownik ma dalej
  // pisać w polu, a czytnik i tak przeczyta wskazaną pozycję.
  const input = $('rqSub');
  if (input) input.setAttribute('aria-activedescendant', items[n].id);
}

function closeSubList() {
  const list = $('rqSubList'), input = $('rqSub');
  if (list) { list.classList.add('hidden'); list.innerHTML = ''; }
  if (input) { input.setAttribute('aria-expanded', 'false'); input.removeAttribute('aria-activedescendant'); }
}

async function refreshParts() {
  const at = currentType();
  if (!at || !at.allowHours) { reqState.part = { can: false, from: [], to: [] }; reqState.fromPart = null; reqState.toPart = null; return; }
  const r = await send({ type: 'partDay', req: {
    absenceTypeId: reqState.absenceTypeId, absenceStart: reqState.absenceStart,
    absenceEnd: reqState.absenceEnd, fromPart: reqState.fromPart, toPart: reqState.toPart } });
  reqState.part = (r && typeof r.can === 'boolean') ? r : { can: false, from: [], to: [] };
  if (reqState.part.can) {
    if (!reqState.part.from.includes(reqState.fromPart)) reqState.fromPart = reqState.part.from[0] || null;
    if (!reqState.part.to.includes(reqState.toPart)) reqState.toPart = reqState.part.to[0] || null;
  } else { reqState.fromPart = null; reqState.toPart = null; }
}

function renderRestrictions() {
  const at = currentType();
  const ent = ((snap && snap.absence && snap.absence.allTypes) || []).find(x => String(x.absenceTypeId) === String(at && at.id));
  const rules = (ent && ent.restrictions) || [];
  if (rules.length) {
    reqMsg('info', `<b>${esc(t('rulesFor'))}</b><ul class="restr">` +
      rules.map(r => `<li>${esc(r)}</li>`).join('') + '</ul>');
  } else reqMsg('', '');
}

function workdays(from, to) {
  const a = parseDay(from), b = parseDay(to);
  if (isNaN(a) || isNaN(b) || b < a) return -1;
  let n = 0;
  for (const d = new Date(a); d <= b; d.setDate(d.getDate() + 1)) { const w = d.getDay(); if (w !== 0 && w !== 6) n++; }
  return n;
}
function updateDays() {
  const n = workdays(reqState.absenceStart, reqState.absenceEnd);
  const el = $('fDays');
  el.classList.remove('hidden');
  if (n < 0) { el.classList.add('bad'); el.textContent = t('badDates'); $('fSend').disabled = true; return; }
  el.classList.remove('bad');
  el.textContent = `${t.n(n, 'workday')} · ${t('daysNote')}`;
  $('fSend').disabled = false;
}

function closeReqForm(returnFocus) {
  $('reqForm').classList.add('hidden');
  $('bRequest').textContent = t('request');
  $('bRequest').setAttribute('aria-expanded', 'false');
  if (returnFocus) $('bRequest').focus();
}

$('bRequest').onclick = async () => {
  const f = $('reqForm');
  const opening = f.classList.contains('hidden');
  if (!opening) { closeReqForm(true); return; }

  $('bRequest').disabled = true;
  $('bRequest').textContent = t('loadingForm');
  const types = await send({ type: 'absenceTypes' });
  $('bRequest').disabled = false;
  if (!Array.isArray(types) || !types.length) {
    $('bRequest').textContent = t('request');
    $('bRequest').setAttribute('aria-expanded', 'true');
    $('reqForm').classList.remove('hidden');
    $('reqFields').innerHTML = '';
    reqMsg('err', 'Nie udało się pobrać typów nieobecności z Calamari.');
    $('reqMsg').focus();
    return;
  }
  reqTypes = types;
  reqState = { absenceTypeId: types[0].id, absenceStart: todayISO(), absenceEnd: todayISO(),
               reason: '', comment: '', substitute: null, substituteName: null,
               fromPart: null, toPart: null, part: { can: false, from: [], to: [] } };
  await refreshParts();
  f.classList.remove('hidden');
  $('bRequest').textContent = t('hideForm');
  $('bRequest').setAttribute('aria-expanded', 'true');
  renderFields();
  // Formularz rozwija się pod przyciskiem. Bez przeniesienia fokusu
  // użytkownik klawiatury musiałby zgadywać, że coś się pojawiło.
  // preventScroll, bo zaraz przewijamy sami i nie chcemy się z tym bić.
  const first = $('rqType');
  if (first) first.focus({ preventScroll: true });
  revealForm();
};

/* Formularz wysuwa się na dole panelu, więc po otwarciu widać z niego skrawek.
   Przewijamy tak, żeby jego górna krawędź wypadła mniej więcej w połowie
   wysokości — wtedy od razu widać rodzaj nieobecności i daty, a nie sam
   nagłówek. Nie przewijamy na samą górę formularza, bo wtedy znika przycisk,
   który go otworzył, i gubi się kontekst. */
function revealForm() {
  const f = $('reqForm');
  const box = document.scrollingElement || document.documentElement;
  if (!f || !box) return;
  const smooth = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  requestAnimationFrame(() => {
    const top = f.getBoundingClientRect().top + box.scrollTop;
    box.scrollTo({ top: Math.max(0, top - box.clientHeight * 0.45),
                   behavior: smooth ? 'smooth' : 'auto' });
  });
}

$('fCancel').onclick = () => closeReqForm(true);

$('reqForm').onsubmit = async e => {
  e.preventDefault();
  const at = currentType();
  if (!at) return;

  // Walidacja: komunikat + aria-invalid na polu + fokus na brakujące pole.
  // Sam czerwony tekst nad formularzem nie mówi, które pole jest puste.
  const fail = (msg, fieldId) => {
    reqMsg('err', msg);
    const f = $(fieldId);
    if (f) { f.setAttribute('aria-invalid', 'true'); f.focus(); }
    else $('reqMsg').focus();
  };
  for (const f of $('reqFields').querySelectorAll('[aria-invalid]')) f.removeAttribute('aria-invalid');
  if (at.substitute === 'REQUIRED' && !reqState.substitute) { fail(t('needSubstitute'), 'rqSub'); return; }
  if (at.comment === 'REQUIRED' && !String(reqState.comment || '').trim()) { fail(t('needComment'), 'rqComment'); return; }
  if (at.reason === 'REQUIRED' && !String(reqState.reason || '').trim()) { fail(t('needReason'), 'rqReason'); return; }

  $('fSend').disabled = true;
  reqMsg('info', t('checking'));
  const payload = { absenceTypeId: reqState.absenceTypeId, absenceStart: reqState.absenceStart,
    absenceEnd: reqState.absenceEnd, reason: reqState.reason, substitute: reqState.substitute,
    comment: reqState.comment, fromPart: reqState.fromPart, toPart: reqState.toPart, typeName: at.name };

  const viol = await send({ type: 'validateRequest', req: payload });
  if (Array.isArray(viol) && viol.length) {
    reqMsg('err', `<b>${esc(t('rejected'))}</b><ul class="restr">` +
      viol.map(v => `<li>${esc(v.message || v.name || JSON.stringify(v))}</li>`).join('') + '</ul>');
    $('fSend').disabled = false;
    $('reqMsg').focus();
    return;
  }

  reqMsg('info', t('sending'));
  const r = await send({ type: 'submitRequest', req: payload });
  $('fSend').disabled = false;
  if (!r || r.ok === false) {
    reqMsg('err', t('rejected') + ' ' + ((r && r.reason) || '') + ' ' + t('nothingSaved'));
    $('reqMsg').focus();
    return;
  }
  reqMsg('ok', `${t('sent')}${r.requestId ? ` (${esc(r.requestId)})` : ''}${r.demo ? ' — ' + t('demoMode') : ''}.`);
  setTimeout(() => { closeReqForm(true); reqMsg('', ''); }, 2500);
  refresh();
};

$('bSignin').onclick = () => send({ type: 'openLogin' });

$('openApp').onclick = () => chrome.tabs.create({ url: CLOCK_URL });

// Teksty, które nie są w HTML-u: ustawiamy je raz, zanim przyjdzie pierwszy stan.
applyStaticTexts();

try {
  chrome.runtime.onMessage.addListener(msg => {
    if (dead) return;
    if (msg && msg.type === 'state') { msg.snap._renderedAt = msg.snap.sampledAt || Date.now(); render(msg.snap); }
  });
} catch (e) { teardown(); }

refresh();


// Embedded pill panels are refreshed by the parent content script. Standalone
// panels poll while visible; the worker coalesces reads from all displays.
if (host !== 'pill') {
  poller = setInterval(() => {
    if (!dead && !document.hidden && !actionPending) refresh();
  }, 2000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !dead && !actionPending) refresh(true);
  });
  window.addEventListener('focus', () => {
    if (!dead && !actionPending) refresh(true);
  });
  for (const event of ['pageshow', 'online']) window.addEventListener(event, () => {
    if (!dead && !actionPending) refresh(true);
  });
  document.addEventListener('resume', () => {
    if (!dead && !actionPending) refresh(true);
  });
}
