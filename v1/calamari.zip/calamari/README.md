# Prototyp rozszerzenia Calamari — 0.7.12

Rozszerzenie ma dwa osobne tryby: **na żywo** i **atrapa**. Od 0.7.4 tryb na żywo **nie wymaga otwartej karty Calamari** — rozmawia z aplikacją wprost, a po kartę sięga tylko wtedy, gdy bezpośrednio się nie da. Błąd połączenia pokazuje brak danych, nigdy przykładowy licznik ani fikcyjne saldo.

## Aktualizacja

1. Otwórz `chrome://extensions` w przeglądarce, w której jest zainstalowany widżet.
2. Przeładuj rozszerzenie; na kafelku powinna pojawić się wersja **0.7.12**.
3. Odśwież otwarte strony z widżetem oraz panel i opcje rozszerzenia.
4. W panelu można ponowić pobieranie przyciskiem **Odśwież**. W opcjach **Test karty** sprawdza uruchomienie skryptu oraz odpowiedź serwera i podaje ID wybranej karty.

Przy pierwszej instalacji: włącz tryb dewelopera na `chrome://extensions`, wybierz „Wczytaj rozpakowane” i wskaż ten katalog `extension/`.

## Co zmienia 0.7.12

Wydanie z dwóch zgłoszeń o to samo: widżet pokazywał stan, którego nie powinien pokazywać.

- **Wyłączony widżet migał przy wczytywaniu strony.** Pigułka trafiała do DOM widoczna, a o tym, czy ma jej w ogóle nie być, decydował dopiero pierwszy snapshot z service workera. Uśpiony worker MV3 wstaje kilkadziesiąt–kilkaset ms i przez ten czas wyłączona pigułka stała na stronie: zmierzone 14–25 ms w Chromium przy rozgrzanym workerze, więcej przy zimnym starcie przeglądarki. Teraz pigułka rodzi się ukryta, a o wczesnym pokazaniu decyduje odczyt ustawień wprost ze `storage`, który workera nie budzi. Dla włączonego widżetu nic się nie zmienia: „łączę…" pojawia się tak samo szybko.
- **Ustawienie zmienione poza tym oknem nie docierało nigdzie.** Worker nie nasłuchiwał `chrome.storage.onChanged`, a odświeżenie wołał ręcznie każdy handler wiadomości z osobna. Zmiana przyniesiona przez synchronizację `storage.sync` z drugiego komputera nie unieważniała więc niczego: worker podawał dalej ustawienia sprzed zmiany, a pigułka ukryta takim nieświeżym stanem przestawała o cokolwiek pytać i zostawała schowana do czasu powrotu do karty. Teraz na zmianę ustawień reaguje jedno miejsce, bez względu na to, skąd zmiana przyszła. `pillPos` jest z tego wyłączony, bo pozycję uzgadnia sama pigułka.

**Czego pilnują nowe testy:** `tests/pill-flash.cjs` sprawdza w prawdziwym rozszerzeniu `display` hosta w chwili wstawienia do DOM, czyli bez zależności od czasu, i osobno to, że włączony widżet nadal się pokazuje. `tests/settings-sync.cjs` odtwarza ustawienie zmienione poza oknem i pilnuje, żeby jedna zmiana ustawień rozsyłała stan dokładnie raz, a nie dwa razy.

## Co zmienia 0.7.11

Wydanie z przeglądu kodu (27.10.2026). Wszystkie 51 testów przechodziło i mimo to w kodzie siedziało 12 usterek — to były luki w pokryciu, nie regresje.

**Bijące na żywym koncie:**
- **Lista projektów gubiła fokus co 2 sekundy.** Każde odpytanie przepisywało `innerHTML` listy, więc element pod fokusem znikał z DOM-u i wybieranie strzałkami urywało się w połowie. Otwarta lista nie jest już przerysowywana.
- **„Dzisiaj nieobecni" zostawało po wyłączeniu modułu Nieobecności** — sekcją sterował wyłącznie `renderLeave()`, a ta przy wyłączonym module w ogóle nie leci.
- **Zasady typu nieobecności nigdy się nie pokazywały.** Mapowanie gubiło pole `restrictions`, które żywe API zwraca jako gotowe zdania. Funkcja działała wyłącznie na atrapie w teście.
- **Przesuwanie pigułki strzałkami wypalało limit zapisu.** Zapis przy każdym wciśnięciu wyczerpywał limit `storage.sync` (~120/min) w kilka sekund i pozycja po cichu przestawała się zapisywać. Teraz zapis jest odroczony.
- Diagnostyka w opcjach pisała „18 undefined" — pole `unit` zniknęło przy przejściu na `hours`.

**Bijące poza Polską albo w wariancie B:**
- **Daty nieobecności o dzień za wcześnie na zachód od UTC.** `new Date('2026-11-02')` to północ UTC; czytana lokalnie dawała w USA 1 listopada, a liczenie dni roboczych łapało zły weekend.
- **Formularz wniosku podstawiał wczorajszą datę po polskiej północy** (doba UTC zamiast lokalnej).
- **`Cmd+Shift+U` w wariancie B przestał udawać, że coś robi.** Wcześniej przestawiał `pillHidden` — flagę pigułki, której w side panelu nie ma. Teraz próbuje otworzyć panel boczny. **Sprawdzone u użytkownika: nadal nie otwiera.** Prawdopodobna przyczyna: `chrome.sidePanel.open()` wymaga gestu użytkownika, a my wołamy go dopiero po `await settings()` i `await tabs.query()`, co ten gest zużywa. Sebastian uznał (27.10.2026), że w wariancie B skrót nie jest potrzebny — zostawiamy próbę, bo jest nieszkodliwa, ale **nie twierdzimy, że działa**.

**Sprzątanie:**
- `sw.js` wołał `inspectAbsenceForm()`, która nie istnieje (mina na `ReferenceError`).
- `Mock.submitRequest` był zadeklarowany dwa razy; pierwszy, na starym kontrakcie, był nieosiągalny.
- Sonda rozpoznająca API gubiła żądania przy równoczesnych zapisach.
- `resolveTransport(force)` ignorował `force`, więc przycisk „Czy karta jest potrzebna?" mógł pokazać odpowiedź z pamięci.

**Panel pigułki powstaje leniwie.** Kontener z ramką lądował wcześniej w DOM każdej odwiedzanej strony. Nie tworzymy go już, dopóki ktoś nie otworzy widżetu — mniej pamięci i o jeden wstrzyknięty element mniej na cudzych stronach.

**Czego NIE poprawiono, bo nie było nasze:** zgłoszone ostrzeżenie `upgrade-insecure-requests ... report-only` pojawia się identycznie bez rozszerzenia. To polityka CSP samego Slite; Chrome przypisał je do `pill.js`, bo nasz skrypt był akurat na stosie. `tests/csp-noise.cjs` pilnuje tego, co faktycznie od nas zależy: że nie dokładamy hałasu ponad to, co strona wypisuje sama.

**Nowe zestawy testów:** `dates.cjs` (strefy czasowe), `probe.cjs` (wyścig w sondzie), `csp-noise.cjs` (hałas na cudzych stronach). Plus pokrycie w `a11y.cjs` (fokus listy, sekcja nieobecnych), `browser.cjs` (zasady typu, skrót w wariancie B) i `pill-pos.cjs` (odroczony zapis pozycji). Każdą poprawkę sprawdzono też od drugiej strony — po cofnięciu kodu test ma padać.

## Co zmienia 0.7.10

- **Powrót bez przeładowywania strony.** Przy starcie przeglądarki, aktywacji karty i jej odmrożeniu worker sprawdza, czy widżet odpowiada, i w razie potrzeby go przywraca. Zdrowy widżet i otwarty formularz nie są przebudowywane. Pigułka odtwarza też elementy usunięte przez stronę.
- **Chwilowy brak odbiorcy nie usuwa widżetu.** Pigułka i panel ponawiają odczyt; tylko faktycznie unieważniony kontekst rozszerzenia kończy starą instancję.
- **Lżejszy rozruch.** Ukryty panel ładuje się przy pierwszym otwarciu, a równoległe odczyty współdzielą jedno sprawdzenie transportu. Potwierdzenie startu i pozostałych akcji zegara nie czeka na ponowne pobranie kalendarza nieobecności.
- Chwilowy brak sieci lub sesji nie zostaje zapamiętany jako wymóg karty Calamari. Zapisany fallback CORS jest ponownie sprawdzany po minucie. Timeout obejmuje także ciało odpowiedzi i przerywa połączenie; zapisów nie ponawiamy.
- **Uprawnienia hosta obejmują HTTP/HTTPS**, zgodnie z dotychczasowym zakresem automatycznych content scripts. Poprzednio programowe przywracanie działało tylko w domenach Calamari; potwierdzono odmowę na zwykłej stronie w Chromium. Chronione strony przeglądarki nadal nie obsługują widżetu.
- Regresje: `tests/recovery.cjs` (6 testów transportu) i `tests/wake.cjs` (przywracanie na zwykłej stronie, rzeczywiste freeze/resume strony, osierocona instancja, chwilowy brak odbiorcy oraz start przy zawieszonym kalendarzu). Wszystko na lokalnych odpowiedziach, bez zmiany ewidencji użytkownika.

## Co zmienia 0.7.9

- **Przerwy korzystają z `allowedBreakTypes` pracownika.** Stały `breakType: 2` powodował HTTP 400 `BREAK_TYPE_NOT_AVAILABLE`. Przy jednym typie przycisk uruchamia ten typ, przy kilku trzeba wybrać nazwę, a przy pustej liście przycisk jest zablokowany z wyjaśnieniem. Przed zapisem lista jest pobierana ponownie; usunięty typ nie zostanie wysłany.
- Odmowa dostępności przerwy ma czytelny komunikat zamiast JSON-a i mylącego ostrzeżenia o braku potwierdzenia. Niepewne błędy transportu nadal wymagają sprawdzenia stanu, a żaden zapis nie jest ponawiany automatycznie.
- `tests/breaks.cjs` sprawdza wybór i walidację typu oraz brak ponowień. `tests/sync.cjs` klika prawdziwy panel i sprawdza pojedynczy typ o ID 17, wybór ID 42, brak typów, zmianę ustawień i HTTP 400. Testy korzystają z lokalnych odpowiedzi API; nie zmieniają ewidencji na żywym koncie.

## Co zmienia 0.7.8

- **Koniec migotania ikon w pasku rozszerzeń.** Każde `chrome.action.set*` każe Chrome przerysować pasek, a widżet malował badge przy każdym opublikowanym stanie: **54 wywołania na minutę, wszystkie z tą samą wartością** (zmierzone, nie oszacowane). Teraz maluje tylko to, co faktycznie się zmieniło — w spoczynku zero wywołań. Pilnuje tego `tests/badge.cjs`, który liczy wywołania w prawdziwym rozszerzeniu i sprawdza obie strony: że w spoczynku ikona stoi, ale przy zmianie stanu nadal się odświeża.

## Co zmienia 0.7.7

- **Typ z obowiązkowym załącznikiem odsyła na stronę.** `attachmentRequirement: REQUIRED` znaczy, że wniosek bez pliku jest niekompletny. Widżet mówi to od razu po wyborze typu, chowa resztę pól i daje przycisk do `/absence/request` — zamiast pozwolić wypełnić formularz i dopiero potem oberwać odmową (albo, gorzej, założyć wniosek bez wymaganego dokumentu).
- **Naprawiony skok pigułki po przeciągnięciu.** Wracała na chwilę na stare miejsce: odczyt rozpoczęty przed przeciągnięciem wracał ze starą pozycją i miał numer `revision` sprzed zapisu, więc strażnik go nie odrzucał. Po przeciągnięciu widżet trzyma własną pozycję, dopóki zapis nie wróci. Regresję pilnuje `tests/pill-pos.cjs`.

## Co zmienia 0.7.6

- **Formularz wniosku nie pokazuje już bloku o załącznikach.** Brak pola sam w sobie mówi, że nie da się nic dodać; komunikat tylko zabierał miejsce i przy każdym wniosku przypominał o niedokończonej funkcji. Flaga `attachmentRequirement` z serwera zostaje w danych typu i wróci do interfejsu, gdy rozpoznamy format `attachments[]`.

## Co zmienia 0.7.5

- **Limity mają dwa układy, przełączane liczbą typów.** Do czterech: kafelki 2×2 z dużą liczbą (tak będzie u większości firm). Powyżej czterech: wiersz na typ, bo kafelki zjadłyby pół panelu. Nieparzysty ostatni kafelek rozciąga się na oba słupki, żeby nie wisiał samotnie.
- Jednostka („dni", „godz.") jest przypisem do liczby, nie jej częścią — w kafelku drobna, obok dużej liczby. W treści oddzielona spacją, bo „12dni" czytnik ekranu czyta jako jeden wyraz.

## Co zmienia 0.7.4

- **Koniec z wymogiem otwartej karty.** Backend odrzucał żądania przez `403 Invalid CORS request`, ale Spring włącza filtr CORS tylko wtedy, gdy nagłówek `Origin` jest — reguła `declarativeNetRequest` go zdejmuje. Widżet działa po zamknięciu wszystkich kart Calamari. Jeśli u kogoś nie zadziała (np. `SameSite` na ciasteczku sesji), po cichu wraca do drogi przez kartę. Dowód: `tests/no-tab.cjs`. Szczegóły: `../06_api-research.md` sekcja 9.
- Nowy przycisk w opcjach: **„Czy karta jest potrzebna?"** — sprawdza na nowo i pokazuje atrybuty `SameSite` ciasteczek.
- **Widać wszystkie limity urlopowe, nie dwa.** Na koncie testowym pracownik ma ich siedem; kafelki z wielką liczbą mieściły dwa i ukrywały resztę. Teraz wiersz na typ, jak na ekranie „Dostępność" w Calamari.
- Nazwy typów idą z serwera **bez żadnych przeróbek** — administrator wpisuje je ręcznie i bywają wielojęzyczne w jednej firmie.
- **Zapis nadal nie ponawia się innym transportem.** Odczyt może się przełączyć w locie, zapis nigdy — „jeden zapis = jedno żądanie" zostaje bez wyjątków.

## Co zmienia 0.7.3

- **Awatary zamiast listy nazwisk.** Rząd twarzy jak na Slacku; nazwisko, typ nieobecności i okres są w dymku pod kursorem. Dymek wychodzi też na fokus z klawiatury i ma odpowiednik w `aria-label`, bo samego hovera nie da się dosięgnąć bez myszy.
- **Podział na „Nieobecność" i „Praca poza biurem".** Kategoria siedzi w typie nieobecności (`TIMEOFF` / `WORK`), nie w zdarzeniu — widżet robi dwa równoległe zapytania z filtrem `absenceCategories` i klasyfikuje serwer. Szczegóły: `../06_api-research.md` sekcja 8.
- Niezatwierdzony wniosek ma bursztynową obwódkę wokół twarzy (plus słowami w dymku i w etykiecie — sam kolor nic nie mówi).
- **Naprawione „sick Leave".** Nazwy typów są wpisywane ręcznie przez administratora i bywają wielojęzyczne w jednej organizacji; pierwszą literę zmniejszamy tylko wtedy, gdy w reszcie nazwy nie ma wielkich liter.
- Daty w nieobecnościach idą przez `Intl`, nie przez polską tablicę miesięcy — po przełączeniu konta na angielski nie ma już „2–6 listopada".

## Co zmienia 0.7.2

- **Nieobecności firmowe działają na żywo.** Rozpoznany `POST /absence/absence/searchAbsenceRequestsForCalendar.do` (kontrakt i pułapki: `../06_api-research.md` sekcja 8). Sekcja „Dzisiaj nieobecni" przestała być ukryta, a „Twoje zaplanowane nieobecności" przestały być pustą tablicą.
- Niezatwierdzone wnioski są oznaczone („wniosek czeka") zamiast podawane jako pewnik.
- **Usunięta zmyślona grupa „praca poza biurem"** z trybu atrapy — API nie zwraca takich zdarzeń.
- Formularz wniosku po otwarciu sam się przewija, żeby było go widać od połowy panelu.

## Co zmienia 0.7.1

- **Pasek „Na żywo przez kartę" zniknął.** Działające połączenie nie jest informacją — dowodem, że działa, są same dane. Pasek pokazuje się wyłącznie przy usterce.
- **Dostępność.** Cały panel, pigułka i strona opcji działają z samej klawiatury i mają nazwy dla czytnika ekranu. Najważniejsze: wybór wariantu w opcjach był wcześniej `div`-em z `onclick`, czyli nie dało się go w ogóle obsłużyć bez myszy; lista projektów nie reagowała na strzałki; ring fokusa miał kontrast 1,72:1, czyli był niewidoczny. Pełna lista i znany dług: `../05_design.md` sekcja 9a.
- Nowy zestaw `tests/a11y.cjs` (26 asercji) plus asercje dostępności pigułki w `tests/sync.cjs`.

## Co zmienia 0.4.0

- **Przypisywanie projektu działa.** Projekt nie jest częścią `clock-in` — aplikacja przypisuje go osobnym żądaniem. Źródło: bundle Calamari 7.15.0.

  ```
  POST /webapi/clockin/workloging/switch-job       {projectId}   // od teraz
  POST /webapi/clockin/workloging/from-beginning   {projectId}   // od początku zmiany
  POST /webapi/clockin/workloging/get-current      {}            // bieżący projekt zmiany
  ```

  `projectId: null` oznacza „bez projektu". Rozszerzenie używa `switch-job`; start pracy z wybranym projektem to `clock-in`, a zaraz po nim `switch-job`.
- **Dropdown jest widoczny zawsze**, nie tylko przed startem — projekt przełącza się też w trakcie pracy. Przed startem wybór jest zapamiętywany lokalnie i przypisywany dopiero po rozpoczęciu; podpowiedź pod listą mówi, co się stanie.
- **Własny listbox zamiast natywnego `<select>`.** Natywnego nie da się pomalować (systemowa niebieska obwódka), a projekty mają kolory, które chcemy pokazać. Lista rozwija się w strumieniu, nie absolutnie, bo panel bywa w iframe o stałej wysokości.
- Odczyt stanu to teraz **cztery zapytania** zamiast trzech — doszedł bieżący projekt zmiany. Do sprawdzenia przy okazji: czy `clock-screen/get` niesie projekt w `dayShifts`; jeśli tak, to zapytanie da się wyciąć.

`tests/projects.cjs` sprawdza 15 rzeczy: widoczność dropdownu w każdym stanie, brak natywnego selecta, kolory i kształt kropek, wysyłkę `setProject` z właściwym id, `null` dla „bez projektu", brak ruchu sieciowego przed startem oraz kolejność `clock-in` → `switch-job`.

## Co zmienia 0.3.8

- **Po zakończeniu pracy duży licznik pokazuje sumę dnia, nie zero** — tak jak zegar w aplikacji. Podpis mówi, ile zmian i że to łączny czas, a etykieta zmienia się na „Praca zakończona". Dzień bez ani jednej zmiany dalej pokazuje `0:00:00` i zachętę do startu.
- To samo w pigułce: po stopie niesie sumę dnia zamiast napisu „Start". Ikona rozszerzenia dostaje szary badge z tą samą liczbą.
- Sumy dnia liczy **service worker** i wysyła je w snapshocie (`dayWorkSeconds`, `dayBreakSeconds`). Wcześniej liczył je panel u siebie, więc pigułka nie miała do nich dostępu i obie powierzchnie mogły się rozjechać.

## Co zmienia 0.3.7

- Pasek planu pracy zastąpiony **osią czasu dnia**, odwzorowującą pasek z zakładki Zegar: jaśniejsze pole to zaplanowane godziny, zielone bloki to faktyczne zmiany w swoich realnych miejscach, żółte slivery to przerwy, pionowa kreska to „teraz". Otwarta zmiana i trwająca przerwa rosną co sekundę.
- Oś jest opisana czasem ściennym pracownika (`screen.timezone`), a nie czasem przeglądarki. Znaczniki zmian przychodzą jako czas absolutny, plan dnia jako czas ścienny — bez przeliczenia oś rozjeżdżałaby się każdemu poza strefą konta.
- Pod osią trzy liczby z zakładki: **przepracowane**, **przerwy**, **pozostało do planu**. To sumy całego dnia; duży licznik wyżej dalej pokazuje bieżącą zmianę. Dwie różne liczby, obie poprawne — stąd podpowiedzi po najechaniu.
- Czas pracy liczony przez wszystkie zmiany dnia z wycięciem przerw niepłatnych (nachodzące na siebie scalane). Przerwy płatne zostają w czasie pracy.

`tests/timeline.cjs` renderuje prawdziwy `ui/panel.html` w Chromium i sprawdza 18 rzeczy: pozycje pięciu zmian, dwie przerwy, okno planu, znacznik „teraz", zgodność sum ze zrzutem z zakładki (02:33:56 / 00:01:27 / 05:26:04), dzień zakończony i dzień wolny.

## Co zmienia 0.3.6

- Żółty licznik mierzy bieżącą przerwę od `breakStarted`, zamiast liczyć od początku zmiany. Tyka co sekundę także pomiędzy odczytami serwera; pigułka pokazuje ten sam czas.
- Pod licznikiem przerwy jest jej własna godzina rozpoczęcia („Przerwa od…”).
- Po powrocie do pracy licznik pokazuje czas bieżącej zmiany pomniejszony o niepłatne przerwy. Przerwy płatne pozostają w czasie pracy.
- Pasek planu pracy korzysta z czasu pracy, a nie z długości wyświetlanej przerwy.
- Pola API sprawdzono w publicznym kodzie aplikacji Calamari 7.15.0. Testy używają teraz rzeczywistych nazw `STARTED`, `finishedTime`, `breakStarted`, `breakFinished`, `paidBreak`.

`tests/clock.cjs` sprawdza obliczenia przerw i pracy, a `tests/sync.cjs` płynne tykanie w iframe i pigułce, przejście przez pełną minutę oraz powrót do pracy. Test przeglądarkowy korzysta z lokalnych odpowiedzi API, nie z żywego konta.

## Co zmieniła 0.3.5

- Widoczna pigułka i osobny panel regularnie pytają o nowy stan. Wspólny cache 5 s ogranicza ruch do API. Zmiany wykonane w Calamari docierają do widżetu zwykle w ciągu kilku sekund, bez czekania na alarm 30 s.
- Otwarcie pływającego panelu i powrót do karty odświeża stan. Każdy nowy odczyt jest rozsyłany także do panelu osadzonego w iframe.
- Start/Stop/Przerwa/Powrót wysyłają zapis raz, a następnie sprawdzają stan serwera. Kolejne przyciski pozostają zablokowane do zakończenia synchronizacji. Przy opóźnionym stanie ponawiany jest wyłącznie odczyt.
- Każdy snapshot ma numer wersji. Spóźniona odpowiedź ze stanem poprzedniej zmiany nie może nadpisać nowej.
- Samo HTTP 204 bez potwierdzenia zmiany stanu nie jest przedstawiane jako zakończona akcja.

Regresję braku odświeżania odtworzono na 0.3.4: test zewnętrznego Stop nie otrzymał aktualizacji przez 8 s. Ten sam test przechodzi na 0.3.5. Dodatkowy test `tests/sync.cjs` klika przyciski w rzeczywistym iframe pływającego panelu i odczytuje napis pigułki z jej zamkniętego Shadow DOM przez protokół debugowania Chromium.

## Co zmieniła 0.3.4

- Wybór aktywnej lub ostatnio używanej karty aplikacji zamiast pierwszej karty `*.calamari.io`. Karty odrzucone z pamięci, zamrożone i obce subdomeny są pomijane.
- `injectImmediately: true` uruchamia zapytanie bez czekania na pełne załadowanie strony. Dowstrzykiwanie pigułki w karty odbywa się równolegle.
- Jeden transport: XHR ze świata strony (`MAIN`), zgodny z transportem zaobserwowanym w aplikacji. Brak kolejnych prób zapisów po błędzie transportu bezpośredniego.
- XHR ma limit 6 s; worker czeka na wynik maksymalnie 8 s. Skrypt uruchomiony po swoim terminie nie wysyła żądania. Timeout zapisu oznacza brak potwierdzenia — trzeba sprawdzić stan w Calamari przed ponowieniem.
- Panel, pigułki i badge współdzielą pobieranie stanu oraz krótki cache (5 s). Alarm co 30 s odświeża dane i rozsyła je do interfejsów. Akcje unieważniają cache.
- Pasek połączenia wynika z całego odczytu, a nie z ostatniego zapytania, które nadpisało diagnostykę. Wszystkie liczniki korzystają ze wspólnego momentu odbioru stanu zegara.
- Błąd zegara daje `—` w panelu i „brak połączenia” w pigułce. Nie uruchamia atrapy.
- „Test karty” działa od otwarcia opcji, bez wcześniejszego „Pokaż pigułkę”.

## Zakres

| Element | Tryb na żywo |
| --- | --- |
| Licznik, plan dnia, projekty | Odczyt `clock-screen/get` |
| Start, przerwa, powrót, stop | Zapis przez kartę; potem odczyt stanu serwera |
| Dostępność rejestracji | Odczyt `availability` |
| Limity urlopowe | Odczyt endpointu legacy Nieobecności |
| Wysłanie wniosku | **żywe Calamari** — formularz renderowany z definicji serwera |
| Kto dziś nieobecny | Ukryte; endpoint nie został rozpoznany |

Tryb atrapy wybiera się ręcznie w opcjach. Ma własny licznik, przykładowe limity i formularz zapisujący wyłącznie dane demonstracyjne. Tryb na żywo nigdy nie zapisuje do atrapy.

Warianty interfejsu: **A** — pigułka na stronie, **B** — badge i side panel, **C** — osobne okno. Ustawienia, moduły i przycisk przywracający pigułkę znajdują się w opcjach rozszerzenia. `Cmd+Shift+U` pokazuje lub ukrywa pigułkę.

## Weryfikacja

Testy są w `../tests/`. Nie łączą się z kontem produkcyjnym: test przeglądarkowy uruchamia prawdziwe rozszerzenie MV3 w Chromium, a odpowiedzi Calamari są przechwytywane i podstawiane lokalnie.

Z katalogu projektu:

```sh
node --test tests/transport.cjs tests/clock.cjs tests/breaks.cjs tests/recovery.cjs
# Wymaga zainstalowanego Playwright i Chromium:
node tests/browser.cjs
node tests/sync.cjs
node tests/timeline.cjs
node tests/projects.cjs
node tests/request-form.cjs
node tests/signin.cjs
node tests/a11y.cjs
node tests/no-tab.cjs
node tests/badge.cjs
node tests/wake.cjs
node --test tests/i18n.cjs
node --test tests/wiring.cjs tests/tabs.cjs tests/pill-pos.cjs
# Jeśli Playwright jest zainstalowany poza projektem:
PLAYWRIGHT_MODULE_PATH=/sciezka/do/node_modules/playwright node tests/browser.cjs
```

Sprawdzono: kartę z niedokończonym ładowaniem, wybór aktywnej karty, współdzielenie zapytań, renderowanie panelu, timeout odczytu i zapisu, odmowę 403 bez ponawiania, błędną odpowiedź HTML, ponowne połączenie, brak karty, jawny tryb atrapy i działanie „Test karty”. Osobne testy sprawdzają pomijanie kart zamrożonych i odrzuconych, zakaz spóźnionego zapisu oraz odpowiedź JSON powyżej 20 KB.

**Użytkownik potwierdził poprawny początkowy odczyt zegara w 0.3.4. Synchronizację 0.3.5 zweryfikowano w Chromium z lokalnymi odpowiedziami API, nie na żywym koncie Dia.** Ta przeglądarka zablokowała wykonanie JavaScript przez AppleScript (wymaga flagi startowej). Nie zmieniano jej ustawień ani nie uruchamiano jej ponownie.

## Pliki

- `sw.js` — współdzielony stan, cache, wiadomości, akcje i badge.
- `lib/api.js` — transport przez kartę, API, osobny tryb demonstracyjny.
- `content/pill.js` — pigułka w zamkniętym Shadow DOM, panel w iframe.
- `ui/panel.*` — wspólny panel wszystkich wariantów.
- `ui/options.*` — ustawienia i diagnostyka.

Wnioski z rozpoznania API: `../06_api-research.md`.
