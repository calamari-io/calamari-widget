/* Wariant A — pigułka wstrzykiwana w stronę.
   Przycisk siedzi w closed Shadow DOM (odporność na CSS strony hosta),
   panel w iframe z web_accessible_resources (izolacja za darmo).
   Podział 1:1 jak u ClickUpa, patrz 02_reverse-engineering-clickup.md. */

(() => {
  // nie wstrzykuj sam w siebie (trik ClickUpa)
  const extOrigin = 'chrome-extension://' + chrome.runtime.id;
  try { if (location.ancestorOrigins && location.ancestorOrigins.contains(extOrigin)) return; } catch (e) {}
  /* Przy aktualizacji rozszerzenia na stronie zostaje sierota z poprzedniej wersji.
     Nowa instancja sprząta po niej DOM i przejmuje pałeczkę przez nonce — stara
     zauważy to przy najbliższym odmalowaniu i sama się wyłączy. */
  const BOX = 'calamari-pill-box';
  const PANEL = 'calamari-pill-panel';
  // A navigation event and manifest injection can arrive together. Keep a
  // healthy instance, including its open form, rather than rebuilding it.
  try { if (window.__calamariPillReady?.()) return; } catch (e) {}
  try {
    const a = document.getElementById(BOX); if (a) a.remove();
    const b = document.getElementById(PANEL); if (b) b.remove();
  } catch (e) {}
  const NONCE = Math.random().toString(36).slice(2);
  window.__calamariPill = NONCE;
  let host, shadow, panelBox, snap = null, ticker = null, open = false;

  let dead = false, poller = null, refreshing = false;
  function alive() {
    try { return !!(chrome.runtime && chrome.runtime.id); } catch (e) { return false; }
  }
  // Panel powstaje leniwie, więc jego brak to stan normalny, nie awaria.
  window.__calamariPillReady = () => !dead && alive() &&
    window.__calamariPill === NONCE && !!host?.isConnected;
  function ensureAttached() {
    if (dead || !alive()) return;
    if (host && !host.isConnected) document.documentElement.appendChild(host);
    if (panelBox && !panelBox.isConnected) document.documentElement.appendChild(panelBox);
  }
  // Po przeładowaniu rozszerzenia ten skrypt zostaje na stronie jako sierota.
  // Zamiast rzucać błędami przy każdym tyknięciu — sprzątamy po sobie.
  function teardown() {
    if (dead) return;
    dead = true;
    if (ticker) clearInterval(ticker);
    if (poller) clearInterval(poller);
    try { host && host.remove(); } catch (e) {}
    try { panelBox && panelBox.remove(); } catch (e) {}
    if (window.__calamariPill === NONCE) window.__calamariPill = null;
  }
  async function send(m) {
    if (dead) return null;
    if (!alive()) { teardown(); return null; }
    try {
      return await chrome.runtime.sendMessage(m);
    } catch (e) {
      // A sleeping/restarting worker can briefly have no receiver. Only an
      // invalidated extension context is permanent; reads retry on the poll.
      if (/context invalidated/i.test(String(e))) teardown();
      return null;
    }
  }

  const CSS = `
  :host{all:initial}
  .wrap{position:fixed;right:28px;bottom:28px;z-index:2147483636;
        font:400 14px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Inter,sans-serif}
  .wait .val{color:#5a6e84;font-family:inherit;font-size:12.5px}
  .err .logo{background:#d12c48}
  .err .val{color:#d12c48;font-family:inherit;font-size:12.5px}
  .pill{display:flex;align-items:center;gap:9px;height:44px;padding:0 7px;border-radius:23px;background:#fff;
        box-shadow:0 16px 44px rgba(8,16,38,.24),0 2px 7px rgba(8,16,38,.14);
        border:1px solid rgba(13,29,68,.05);user-select:none;position:relative;width:fit-content}
  .pill.hasval{padding-right:14px}
  .grip{width:12px;display:flex;flex-wrap:wrap;gap:2.5px;cursor:grab;flex:0 0 auto;padding-left:2px}
  .grip i{width:3px;height:3px;border-radius:50%;background:#8b99a9;display:block}
  .grip.grab{cursor:grabbing}
  .logo{width:31px;height:31px;border-radius:50%;background:#21876e;display:grid;place-items:center;
        flex:0 0 auto;position:relative;cursor:pointer;border:0;padding:0}
  .logo:hover{background:#27a082}
  .logo img{width:19px;display:block}
  .logo .live{position:absolute;right:-1px;bottom:-1px;width:9px;height:9px;border-radius:50%;
              background:#65d9bd;border:2px solid #fff}
  .off .logo{background:#5a6e84}
  .off .logo .live{display:none}
  .brk .logo{background:#9a6b00}
  .brk .logo .live{background:#fff}
  .val{font:600 15px/1 ui-monospace,SFMono-Regular,Menlo,monospace;color:#191f25;letter-spacing:.2px}
  .off .val{color:#5a6e84;font-family:inherit;font-size:13.5px}
  .x{position:absolute;top:-5px;right:-5px;width:19px;height:19px;border-radius:50%;background:#5a6e84;
     color:#fff;border:2px solid #fff;display:none;place-items:center;cursor:pointer;padding:0}
  .x svg{width:8px;height:8px;stroke:currentColor;fill:none;stroke-width:3.2;stroke-linecap:round}
  /* focus-within obok hover: bez tego przycisk „schowaj" istnieje wyłącznie
     dla myszy — użytkownik klawiatury nie ma jak go nawet zobaczyć. */
  .pill:hover .x,.pill:focus-within .x{display:grid}
  .x:hover{background:#232b34}
  /* Ring fokusa w kolorze o kontraście 4,4:1 — widżet stoi na cudzej stronie,
     więc nie możemy liczyć na domyślny ring przeglądarki pod naszym tłem. */
  .logo:focus-visible,.x:focus-visible,.grip:focus-visible{
    outline:3px solid #21876e;outline-offset:2px}
  .grip{border:0;background:none}
  @media (prefers-reduced-motion: reduce){
    .pill,.logo{transition:none !important}
  }
  `;

  function build() {
    host = document.createElement('div');
    host.id = BOX;
    shadow = host.attachShadow({ mode: 'closed' });

    const style = document.createElement('style');
    style.textContent = CSS;

    const wrap = document.createElement('div');
    wrap.className = 'wrap';
    /* Uchwyt jest <button>, nie <span>: przeciąganie myszą ma odpowiednik
       na klawiaturze (strzałki), inaczej pozycji widżetu nie da się zmienić
       bez myszy. Licznik w .val jest aria-hidden, bo zmienia się co sekundę —
       nazwę całości niesie aria-label przycisku, odświeżany raz na minutę. */
    wrap.innerHTML = `
      <div class="pill" part="pill" role="group" aria-label="Calamari">
        <button class="grip" type="button" aria-label="Przesuń widżet Calamari"
                aria-keyshortcuts="ArrowUp ArrowDown ArrowLeft ArrowRight">
          <i aria-hidden="true"></i><i aria-hidden="true"></i><i aria-hidden="true"></i>
          <i aria-hidden="true"></i><i aria-hidden="true"></i><i aria-hidden="true"></i>
        </button>
        <button class="logo" type="button" aria-label="Otwórz widżet Calamari"
                aria-haspopup="dialog" aria-expanded="false">
          <img src="${chrome.runtime.getURL('assets/symbol-white.png')}" alt="">
          <span class="live" aria-hidden="true"></span>
        </button>
        <span class="val" aria-hidden="true">łączę…</span>
        <button class="x" type="button" aria-label="Schowaj widżet Calamari — wróci po kliknięciu ikony rozszerzenia">
          <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
      </div>`;
    wrap.classList.add('wait');
    shadow.append(style, wrap);
    /* Pigułka rodzi się ukryta. O tym, czy ma się pokazać, decydują ustawienia,
       a te przychodzą asynchronicznie — widoczność włącza odczyt zaraz pod
       build() albo paint(). Bez tego wyłączony widżet migał na każdej
       odświeżonej stronie (27.10.2026). */
    host.style.display = 'none';
    document.documentElement.appendChild(host);

    wire(wrap);
    return wrap;
  }

  /* Panel powstaje dopiero przy pierwszym otwarciu.

     Wcześniej kontener z <iframe> lądował w DOM każdej odwiedzanej strony.
     Sam `src` był już leniwy, ale pusta ramka i tak tworzy dokument, więc
     przeglądarka parsowała politykę CSP strony — a na stronach, które wysyłają
     `Content-Security-Policy-Report-Only` z dyrektywą `upgrade-insecure-requests`
     (np. Slite), Chrome wypisywał przy tym ostrzeżenie i przypisywał je NAM.
     Zgłoszone 27.10.2026 jako błąd rozszerzenia; to była polityka cudzej
     strony, ale wywoływał ją nasz wstrzyknięty element.

     Przy okazji: na stronach, na których nikt nie otwiera widżetu, nie
     tworzymy już ramki ani nie zajmujemy pamięci panelem. */
  function ensurePanel() {
    if (panelBox) return panelBox;
    panelBox = document.createElement('div');
    panelBox.id = PANEL;
    Object.assign(panelBox.style, {
      position: 'fixed', zIndex: '2147483646', width: '300px', height: '0',
      opacity: '0', visibility: 'hidden', overflow: 'hidden',
      background: '#fff', borderRadius: '12px', border: '1px solid rgba(13,29,68,.06)',
      boxShadow: '0 16px 44px rgba(8,16,38,.24)', transition: 'opacity .14s'
    });
    panelBox.setAttribute('role', 'dialog');
    panelBox.setAttribute('aria-label', 'Widżet Calamari');
    const f = document.createElement('iframe');
    f.title = 'Widżet Calamari';
    Object.assign(f.style, { width: '100%', height: '100%', border: '0', display: 'block' });
    panelBox.appendChild(f);
    document.documentElement.appendChild(panelBox);
    return panelBox;
  }

  function wire(wrap) {
    const pill = wrap.querySelector('.pill');
    const grip = wrap.querySelector('.grip');

    wrap.querySelector('.logo').addEventListener('click', e => {
      if (dragged) return;
      e.stopPropagation();
      toggle();
    });
    wrap.querySelector('.x').addEventListener('click', e => {
      e.stopPropagation(); close(false); send({ type: 'hidePill' });
    });

    /* przeciąganie: próg 20 px odróżnia klik od drag,
       pozycja zapisywana jako odległość od krawędzi (przeżywa resize okna) */
    /* Przesuwanie z klawiatury. Mysz dostaje pointer-drag niżej; tu strzałki
       przesuwają o 20 px (Shift: 100 px) i zapisują pozycję tak samo. */
    grip.addEventListener('keydown', e => {
      const STEP = e.shiftKey ? 100 : 20;
      const d = { ArrowLeft: [-STEP, 0], ArrowRight: [STEP, 0],
                  ArrowUp: [0, -STEP], ArrowDown: [0, STEP] }[e.key];
      if (!d) return;
      e.preventDefault();
      const r = wrap.getBoundingClientRect();
      const x = Math.min(Math.max(8, r.left + d[0]), innerWidth - r.width - 8);
      const y = Math.min(Math.max(8, r.top + d[1]), innerHeight - r.height - 8);
      const pos = { left: x, bottom: Math.max(8, innerHeight - (y + r.height)) };
      zapamietajPozycje(pos);
      applyPos(pos);
      zapiszPozycjePozniej(pos);
    });

    let drag = null;
    grip.addEventListener('pointerdown', e => {
      const r = wrap.getBoundingClientRect();
      drag = { sx: e.clientX, sy: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top };
      dragged = false;
      grip.classList.add('grab');
      grip.setPointerCapture(e.pointerId);
      e.preventDefault();
    });
    grip.addEventListener('pointermove', e => {
      if (!drag) return;
      if (!dragged && Math.abs(e.clientX - drag.sx) < 20 && Math.abs(e.clientY - drag.sy) < 20) return;
      dragged = true;
      close(false);
      const w = wrap.offsetWidth, h = wrap.offsetHeight;
      const x = Math.min(Math.max(8, e.clientX - drag.dx), innerWidth - w - 8);
      const y = Math.min(Math.max(8, e.clientY - drag.dy), innerHeight - h - 8);
      wrap.style.left = x + 'px'; wrap.style.top = y + 'px';
      wrap.style.right = 'auto'; wrap.style.bottom = 'auto';
    });
    const up = () => {
      if (!drag) return;
      grip.classList.remove('grab');
      if (dragged) {
        // snap do bliższej krawędzi
        const r = wrap.getBoundingClientRect();
        const right = Math.max(8, innerWidth - r.right);
        const left = Math.max(8, r.left);
        const bottom = Math.max(8, innerHeight - r.bottom);
        const pos = (left < right) ? { left, bottom } : { right, bottom };
        zapamietajPozycje(pos);
        applyPos(pos);
        send({ type: 'savePos', pos });
      }
      drag = null;
      setTimeout(() => dragged = false, 60);
    };
    addEventListener('pointerup', up);
    addEventListener('pointercancel', up);
  }

  let dragged = false;

  /* Pozycja po przeciągnięciu — skąd się brało „wraca i znowu skacze".

     Po puszczeniu pigułki ustawiamy ją lokalnie i wysyłamy `savePos`. W tym
     samym czasie leci już odczyt rozpoczęty PRZED przeciągnięciem i wraca
     ze starą pozycją. Strażnik epoch/revision go nie odrzuca, bo ten odczyt
     ma jeszcze numer sprzed zapisu — więc pigułka wskakuje na stare miejsce,
     a chwilę później przychodzi broadcast z zapisu i wraca na nowe.

     Rozwiązanie: po przeciągnięciu trzymamy własną pozycję i ignorujemy
     przychodzące, dopóki któraś nie zgodzi się z zapisaną. Wtedy wiadomo,
     że zapis doszedł, i znów słuchamy serwera (np. zmiany z innego okna).
     Bezpiecznik czasowy na wypadek, gdyby zapis nigdy nie wrócił. */
  let mojaPozycja = null, mojaPozycjaDo = 0;

  function tePozycjeSaTakieSame(a, b) {
    if (!a || !b) return false;
    const n = v => (v == null ? null : Math.round(v));
    return n(a.left) === n(b.left) && n(a.right) === n(b.right) && n(a.bottom) === n(b.bottom);
  }

  function uzgodnionaPozycja(zSerwera) {
    const pos = zSerwera || { right: 28, bottom: 28 };
    if (!mojaPozycja) return pos;
    if (tePozycjeSaTakieSame(pos, mojaPozycja) || Date.now() > mojaPozycjaDo) {
      mojaPozycja = null;          // zapis doszedł (albo minął czas) — znów słuchamy
      return pos;
    }
    return mojaPozycja;            // odczyt sprzed przeciągnięcia, nie cofaj
  }

  /* Zapis pozycji po strzałkach — z opóźnieniem.

     `storage.sync` ma limit ok. 120 zapisów na minutę. Przytrzymana strzałka
     powtarza się kilkadziesiąt razy na sekundę, więc zapis przy każdym
     wciśnięciu wyczerpywał limit w kilka sekund i pozycja po cichu przestawała
     się zapisywać. Ruch na ekranie jest natychmiastowy (applyPos wyżej),
     a na dysk trafia dopiero to, na czym użytkownik się zatrzymał. */
  let zapisTimer = null;
  function zapiszPozycjePozniej(pos) {
    clearTimeout(zapisTimer);
    zapisTimer = setTimeout(() => send({ type: 'savePos', pos }), 400);
  }

  function zapamietajPozycje(pos) {
    mojaPozycja = pos;
    mojaPozycjaDo = Date.now() + 10000;
  }

  function applyPos(pos) {
    const wrap = shadow.querySelector('.wrap');
    wrap.style.left = pos.left != null ? pos.left + 'px' : 'auto';
    wrap.style.right = pos.right != null ? pos.right + 'px' : 'auto';
    wrap.style.bottom = (pos.bottom != null ? pos.bottom : 28) + 'px';
    wrap.style.top = 'auto';
    placePanel();
  }

  function placePanel() {
    if (!panelBox) return;
    const wrap = shadow.querySelector('.wrap');
    const r = wrap.getBoundingClientRect();
    const h = 460;
    const left = Math.min(Math.max(8, r.left), innerWidth - 308);
    panelBox.style.left = left + 'px';
    if (r.top > h + 20) {
      panelBox.style.top = (r.top - h - 10) + 'px';
    } else {
      panelBox.style.top = (r.bottom + 10) + 'px';
    }
  }

  function toggle() { open ? close(true) : openPanel(); }
  function openPanel() {
    const frame = ensurePanel().querySelector('iframe');
    if (!frame.hasAttribute('src')) frame.src = chrome.runtime.getURL('ui/panel.html?host=pill');
    refresh(true);
    open = true; placePanel();
    panelBox.style.height = '460px';
    panelBox.style.visibility = 'visible';
    panelBox.style.opacity = '1';
    setLogoState();
    // Fokus wchodzi do panelu, inaczej Tab z pigułki idzie dalej po stronie
    // hosta i użytkownik klawiatury nigdy nie dociera do zawartości widżetu.
    try { panelBox.querySelector('iframe').focus(); } catch (e) {}
  }
  /* visibility:hidden (a nie samo opacity) jest tu konieczne także dla
     dostępności: ukrywa panel w drzewie dostępności i wyjmuje go z Taba. */
  function close(returnFocus) {
    const was = open;
    open = false;
    if (panelBox) {
      panelBox.style.opacity = '0';
      panelBox.style.visibility = 'hidden';
      panelBox.style.height = '0';
    }
    setLogoState();
    if (was && returnFocus && shadow) {
      try { shadow.querySelector('.logo').focus(); } catch (e) {}
    }
  }

  /* Etykieta pigułki. Mówi to, co widać: stan i czas. Odświeżana tylko przy
     zmianie treści — aria-label przepisywany co sekundę zapętla czytnik. */
  let lastLabel = '';
  function setLogoState(text) {
    if (!shadow) return;
    const logo = shadow.querySelector('.logo');
    if (!logo) return;
    logo.setAttribute('aria-expanded', String(open));
    const label = (open ? 'Zamknij widżet Calamari' : 'Otwórz widżet Calamari') +
                  (text ? ' — ' + text : '');
    if (label !== lastLabel) { lastLabel = label; logo.setAttribute('aria-label', label); }
  }

  /* ------------------------------------------------------------- render */

  function paint() {
    if (dead) return;
    if (window.__calamariPill !== NONCE) { teardown(); return; }  // przejęła nas nowsza instancja
    if (!alive()) { teardown(); return; }
    ensureAttached();
    if (!snap || !shadow) return;
    const wrap = shadow.querySelector('.wrap');
    const pill = shadow.querySelector('.pill');
    const val = shadow.querySelector('.val');
    const set = snap.settings;

    const show = (set.modTime || set.modLeave) && !set.pillHidden && set.variant === 'pill';
    host.style.display = show ? '' : 'none';
    if (panelBox) panelBox.style.display = show ? '' : 'none';
    if (!show) { close(false); return; }

    wrap.classList.toggle('off', snap.state === 'STOPPED');
    wrap.classList.toggle('brk', snap.state === 'BREAK');

    if (!set.modTime) {
      // sam moduł Nieobecności — pigułka to uchwyt i logo, bez liczby
      pill.classList.remove('hasval');
      val.style.display = 'none';
      wrap.classList.remove('off', 'brk');
      setLogoState();
      return;
    }
    val.style.display = '';
    pill.classList.add('hasval');

    wrap.classList.toggle('err', snap.state === 'UNKNOWN');
    if (snap.state === 'UNKNOWN') {
      const out = snap.diag && snap.diag.kind === 'WYLOGOWANY';
      val.textContent = out ? 'zaloguj się' : 'brak połączenia';
      setLogoState(val.textContent);
      return;
    }
    if (snap.state === 'STOPPED') {
      // Po zakończeniu pracy pigułka niesie sumę dnia, tak jak duży zegar w aplikacji.
      const day = snap.dayWorkSeconds || 0;
      if (!day) { val.textContent = 'Start'; setLogoState('praca niezaczęta'); return; }
      const h = Math.floor(day / 3600), m = Math.floor(day % 3600 / 60), x = day % 60;
      val.textContent = `${h}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`;
      setLogoState(`praca zakończona, ${spoken(day)}`);
      return;
    }

    // ta sama liczba i ten sam format co w panelu — inaczej wygląda jak błąd
    const sec = snap.seconds + Math.floor((Date.now() - snap._renderedAt) / 1000);
    const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), x = sec % 60;
    val.textContent = `${h}:${String(m).padStart(2,'0')}:${String(x).padStart(2,'0')}`;
    setLogoState(`${snap.state === 'BREAK' ? 'przerwa' : 'trwa praca'}, ${spoken(sec)}`);
  }

  /* Czas słowami do etykiety. Pigułka żyje na cudzej stronie i nie importuje
     lib/i18n (to content script bez modułów), więc ma własną, krótką wersję.
     Sekundy pomijamy celowo — etykieta zmienia się raz na minutę. */
  function spoken(sec) {
    const n = Math.max(0, Math.floor(sec || 0));
    const h = Math.floor(n / 3600), m = Math.floor(n % 3600 / 60);
    const form = (k, a, b, c) => k === 1 ? a
      : (k % 10 >= 2 && k % 10 <= 4 && !(k % 100 >= 12 && k % 100 <= 14)) ? b : c;
    const out = [];
    if (h) out.push(`${h} ${form(h, 'godzina', 'godziny', 'godzin')}`);
    if (m) out.push(`${m} ${form(m, 'minuta', 'minuty', 'minut')}`);
    return out.length ? out.join(' ') : 'mniej niż minuta';
  }

  function showError(txt) {
    if (!shadow) return;
    const wrap = shadow.querySelector('.wrap');
    wrap.classList.remove('wait'); wrap.classList.add('err');
    shadow.querySelector('.val').textContent = txt || 'błąd';
    shadow.querySelector('.val').style.display = '';
  }

  function setSnap(s) {
    if (dead) return;
    if (snap && s?.settings && (s.epoch < snap.epoch || (s.epoch === snap.epoch && s.revision < snap.revision))) return;
    if (!s || s.ok === false || !s.settings) {        // service worker odpowiedział błędem albo niczym
      if (ticker) clearInterval(ticker);
      snap = null;
      showError(s && s.error ? 'SW: ' + String(s.error).slice(0, 40) : 'brak odpowiedzi');
      return;
    }
    shadow.querySelector('.wrap').classList.remove('wait', 'err');
    s._renderedAt = s.sampledAt || Date.now();
    snap = s;
    applyPos(uzgodnionaPozycja(s.settings.pillPos));
    paint();
    if (ticker) clearInterval(ticker);
    if (s.state === 'WORKING' || s.state === 'BREAK') ticker = setInterval(paint, 1000);
  }

  try {
    chrome.runtime.onMessage.addListener((msg, sender, reply) => {
      if (msg?.type === 'pillPing') {
        if (window.__calamariPillReady()) reply({ ok: true });
        return false;
      }
      if (!dead && msg && msg.type === 'state') setSnap(msg.snap);
    });
  } catch (e) { teardown(); }
  addEventListener('resize', () => { placePanel(); });
  /* Panel siedzi w iframe, więc Escape wciśnięty w środku nie dotrze tutaj
     sam z siebie — panel.js przesyła go wiadomością. */
  addEventListener('message', e => {
    if (!dead && e.data && e.data.calamari === 'closePanel') close(true);
  });

  build();
  /* Czy pigułkę w ogóle pokazywać, wiadomo z ustawień — i te czytamy wprost ze
     storage, zamiast czekać na pierwszą odpowiedź service workera. Uśpiony
     worker MV3 wstaje kilkadziesiąt–kilkaset ms i przez ten czas pigułka
     stałaby na stronie u kogoś, kto ją wyłączył. Odczyt storage workera nie
     budzi. Gdy snapshot zdąży pierwszy, rządzi paint() — tu już nie dotykamy. */
  const USTAWIENIA_WSTEPNE = { variant: 'pill', modLeave: true, modTime: true, pillHidden: false };
  /* Odczyt jest dodatkiem przyspieszającym decyzję, nie warunkiem startu:
     gdyby storage był niedostępny, reszta rozruchu musi iść dalej, a pigułkę
     i tak pokaże pierwszy snapshot. */
  try {
    chrome.storage?.sync?.get(Object.keys(USTAWIENIA_WSTEPNE)).then(r => {
      if (dead || snap || !host) return;
      const s = { ...USTAWIENIA_WSTEPNE, ...r };
      if ((s.modTime || s.modLeave) && !s.pillHidden && s.variant === 'pill') host.style.display = '';
    }).catch(() => {});
  } catch (e) {}
  // Jeśli SW nie odpowie, pigułka ma to pokazać, a nie siedzieć w „łączę…" do końca świata.
  let got = false;
  async function refresh(force = false) {
    if (dead || refreshing) return;
    if (window.__calamariPill !== NONCE) { teardown(); return; }
    ensureAttached();
    refreshing = true;
    try {
      const s = await send({ type: 'get', force });
      got = true;
      if (!dead) setSnap(s);
    } finally { refreshing = false; }
  }
  refresh();
  poller = setInterval(() => {
    if (!document.hidden && (!snap || (snap.settings.variant === 'pill' && !snap.settings.pillHidden))) refresh();
  }, 2000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(true); });
  window.addEventListener('focus', () => refresh(true));
  window.addEventListener('pageshow', () => refresh(true));
  window.addEventListener('online', () => refresh(true));
  document.addEventListener('resume', () => refresh(true));
  setTimeout(() => { if (!got && !dead) showError('brak odpowiedzi z rozszerzenia'); }, 14000);
})();
