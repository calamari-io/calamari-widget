/* Most między światem strony a rozszerzeniem. Świat IZOLOWANY, document_start.
   Skrypt w świecie strony nie ma dostępu do chrome.runtime, więc wpisy
   przekazuje przez postMessage, a ten most odsyła je do service workera.
   Dzięki temu log przeżywa przeładowanie ramki po wysłaniu wniosku. */
window.addEventListener('message', ev => {
  const entry = ev.data && ev.data.__calamariProbe;
  if (!entry) return;
  try { chrome.runtime.sendMessage({ type: 'probeLog', entry }).catch(() => {}); } catch (_) {}
});
