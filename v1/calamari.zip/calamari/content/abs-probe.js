/* Podsłuch formularza wniosku urlopowego — świat STRONY, document_start.
   Łapie XHR, fetch oraz natywną wysyłkę formularza, i natychmiast przekazuje
   każdy wpis przez postMessage. Nie trzyma niczego u siebie, bo ramka
   przeładowuje się po wysłaniu wniosku i stan w stronie by przepadł. */
(() => {
  if (window.__absProbe) return;
  window.__absProbe = true;

  const send = e => { try { window.postMessage({ __calamariProbe: e }, '*'); } catch (_) {} };
  const interesting = u => /\/(webapi|absence)\//.test(String(u));
  const bodyOf = b => {
    if (!b) return null;
    if (typeof b === 'string') return b.slice(0, 1200);
    if (b instanceof FormData) {
      const out = [];
      for (const [k, v] of b.entries()) out.push(k + '=' + (typeof v === 'string' ? v.slice(0, 120) : '[plik]'));
      return out.join('&').slice(0, 1200);
    }
    if (b instanceof URLSearchParams) return b.toString().slice(0, 1200);
    return '[' + (b.constructor ? b.constructor.name : typeof b) + ']';
  };
  const at = () => new Date().toTimeString().slice(0, 8);

  const oo = XMLHttpRequest.prototype.open, os = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function (m, u) { this.__m = m; this.__u = u; return oo.apply(this, arguments); };
  XMLHttpRequest.prototype.send = function (b) {
    this.addEventListener('load', () => {
      if (!interesting(this.__u)) return;
      send({ at: at(), kind: 'xhr', method: this.__m, url: String(this.__u),
             body: bodyOf(b), status: this.status, text: String(this.responseText || '').slice(0, 1500) });
    });
    return os.apply(this, arguments);
  };

  const of = window.fetch;
  window.fetch = async function (i, init) {
    const url = (i && i.url) || i;
    const r = await of.apply(this, arguments);
    if (interesting(url)) {
      let text = '';
      try { text = await r.clone().text(); } catch (_) {}
      send({ at: at(), kind: 'fetch', method: (init && init.method) || 'GET', url: String(url),
             body: bodyOf(init && init.body), status: r.status, text: text.slice(0, 1500) });
    }
    return r;
  };

  // Klasyczna wysyłka formularza nie przechodzi przez XHR — łapiemy osobno.
  document.addEventListener('submit', ev => {
    const f = ev.target;
    if (!(f instanceof HTMLFormElement)) return;
    try {
      send({ at: at(), kind: 'form-submit', method: (f.method || 'GET').toUpperCase(),
             url: f.action || location.href, body: bodyOf(new FormData(f)), status: null, text: '' });
    } catch (_) {}
  }, true);
})();
